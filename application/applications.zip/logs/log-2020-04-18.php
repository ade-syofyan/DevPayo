INFO - 2020-04-18 17:27:53 --> Config Class Initialized
INFO - 2020-04-18 17:27:53 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:27:53 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:27:53 --> Utf8 Class Initialized
INFO - 2020-04-18 17:27:53 --> URI Class Initialized
INFO - 2020-04-18 17:27:53 --> Router Class Initialized
INFO - 2020-04-18 17:27:53 --> Output Class Initialized
INFO - 2020-04-18 17:27:53 --> Security Class Initialized
DEBUG - 2020-04-18 17:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:27:53 --> Input Class Initialized
INFO - 2020-04-18 17:27:54 --> Language Class Initialized
INFO - 2020-04-18 17:27:54 --> Config Class Initialized
INFO - 2020-04-18 17:27:54 --> Loader Class Initialized
INFO - 2020-04-18 17:27:54 --> Hooks Class Initialized
INFO - 2020-04-18 17:27:54 --> Helper loaded: url_helper
INFO - 2020-04-18 17:27:54 --> Helper loaded: file_helper
DEBUG - 2020-04-18 17:27:54 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:27:54 --> Utf8 Class Initialized
INFO - 2020-04-18 17:27:54 --> Helper loaded: form_helper
INFO - 2020-04-18 17:27:54 --> URI Class Initialized
INFO - 2020-04-18 17:27:54 --> Database Driver Class Initialized
INFO - 2020-04-18 17:27:54 --> Router Class Initialized
INFO - 2020-04-18 17:27:54 --> Email Class Initialized
INFO - 2020-04-18 17:27:54 --> Output Class Initialized
DEBUG - 2020-04-18 17:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:27:54 --> Security Class Initialized
INFO - 2020-04-18 17:27:54 --> Controller Class Initialized
DEBUG - 2020-04-18 17:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:27:54 --> Input Class Initialized
INFO - 2020-04-18 17:27:54 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:27:54 --> Language Class Initialized
INFO - 2020-04-18 17:27:54 --> Loader Class Initialized
INFO - 2020-04-18 17:27:54 --> Helper loaded: url_helper
INFO - 2020-04-18 17:27:54 --> Helper loaded: file_helper
INFO - 2020-04-18 17:27:54 --> Helper loaded: form_helper
INFO - 2020-04-18 17:27:54 --> Database Driver Class Initialized
INFO - 2020-04-18 17:27:54 --> Email Class Initialized
DEBUG - 2020-04-18 17:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:27:54 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:27:54 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:27:55 --> Config Class Initialized
INFO - 2020-04-18 17:27:55 --> Form Validation Class Initialized
INFO - 2020-04-18 17:27:55 --> Hooks Class Initialized
INFO - 2020-04-18 17:27:55 --> Upload Class Initialized
DEBUG - 2020-04-18 17:27:55 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:27:55 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:27:55 --> Utf8 Class Initialized
INFO - 2020-04-18 17:27:55 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:27:55 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:27:55 --> URI Class Initialized
INFO - 2020-04-18 17:27:55 --> Final output sent to browser
INFO - 2020-04-18 17:27:55 --> Router Class Initialized
DEBUG - 2020-04-18 17:27:55 --> Total execution time: 1.8363
INFO - 2020-04-18 17:27:55 --> Config Class Initialized
INFO - 2020-04-18 17:27:55 --> Hooks Class Initialized
INFO - 2020-04-18 17:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:27:55 --> Output Class Initialized
INFO - 2020-04-18 17:27:55 --> Controller Class Initialized
INFO - 2020-04-18 17:27:55 --> Security Class Initialized
DEBUG - 2020-04-18 17:27:55 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:27:55 --> Utf8 Class Initialized
DEBUG - 2020-04-18 17:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:27:55 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:27:55 --> Input Class Initialized
INFO - 2020-04-18 17:27:55 --> URI Class Initialized
INFO - 2020-04-18 17:27:55 --> Language Class Initialized
INFO - 2020-04-18 17:27:55 --> Router Class Initialized
INFO - 2020-04-18 17:27:55 --> Config Class Initialized
INFO - 2020-04-18 17:27:55 --> Hooks Class Initialized
INFO - 2020-04-18 17:27:55 --> Loader Class Initialized
INFO - 2020-04-18 17:27:55 --> Output Class Initialized
INFO - 2020-04-18 17:27:55 --> Security Class Initialized
INFO - 2020-04-18 17:27:55 --> Helper loaded: url_helper
DEBUG - 2020-04-18 17:27:56 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:27:56 --> Utf8 Class Initialized
DEBUG - 2020-04-18 17:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:27:56 --> Input Class Initialized
INFO - 2020-04-18 17:27:56 --> Helper loaded: file_helper
INFO - 2020-04-18 17:27:56 --> URI Class Initialized
INFO - 2020-04-18 17:27:56 --> Language Class Initialized
INFO - 2020-04-18 17:27:56 --> Router Class Initialized
INFO - 2020-04-18 17:27:56 --> Helper loaded: form_helper
INFO - 2020-04-18 17:27:56 --> Output Class Initialized
INFO - 2020-04-18 17:27:56 --> Loader Class Initialized
INFO - 2020-04-18 17:27:56 --> Database Driver Class Initialized
INFO - 2020-04-18 17:27:56 --> Security Class Initialized
INFO - 2020-04-18 17:27:56 --> Helper loaded: url_helper
INFO - 2020-04-18 17:27:56 --> Email Class Initialized
INFO - 2020-04-18 17:27:56 --> Helper loaded: file_helper
DEBUG - 2020-04-18 17:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-18 17:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:27:56 --> Input Class Initialized
INFO - 2020-04-18 17:27:56 --> Helper loaded: form_helper
INFO - 2020-04-18 17:27:56 --> Language Class Initialized
INFO - 2020-04-18 17:27:56 --> Database Driver Class Initialized
INFO - 2020-04-18 17:27:56 --> Email Class Initialized
INFO - 2020-04-18 17:27:56 --> Loader Class Initialized
INFO - 2020-04-18 17:27:56 --> Helper loaded: url_helper
DEBUG - 2020-04-18 17:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:27:56 --> Helper loaded: file_helper
INFO - 2020-04-18 17:27:56 --> Helper loaded: form_helper
INFO - 2020-04-18 17:27:56 --> Database Driver Class Initialized
INFO - 2020-04-18 17:27:56 --> Email Class Initialized
DEBUG - 2020-04-18 17:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:27:56 --> Config Class Initialized
INFO - 2020-04-18 17:27:56 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:27:56 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:27:56 --> Utf8 Class Initialized
INFO - 2020-04-18 17:27:56 --> URI Class Initialized
INFO - 2020-04-18 17:27:56 --> Router Class Initialized
INFO - 2020-04-18 17:27:56 --> Output Class Initialized
INFO - 2020-04-18 17:27:56 --> Security Class Initialized
DEBUG - 2020-04-18 17:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:27:56 --> Input Class Initialized
INFO - 2020-04-18 17:27:56 --> Language Class Initialized
INFO - 2020-04-18 17:27:56 --> Loader Class Initialized
INFO - 2020-04-18 17:27:56 --> Helper loaded: url_helper
INFO - 2020-04-18 17:27:57 --> Helper loaded: file_helper
INFO - 2020-04-18 17:27:57 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:27:57 --> Config Class Initialized
INFO - 2020-04-18 17:27:57 --> Hooks Class Initialized
INFO - 2020-04-18 17:27:57 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:27:57 --> Helper loaded: form_helper
INFO - 2020-04-18 17:27:57 --> Form Validation Class Initialized
DEBUG - 2020-04-18 17:27:57 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:27:57 --> Database Driver Class Initialized
INFO - 2020-04-18 17:27:57 --> Utf8 Class Initialized
INFO - 2020-04-18 17:27:57 --> Upload Class Initialized
INFO - 2020-04-18 17:27:57 --> Email Class Initialized
INFO - 2020-04-18 17:27:57 --> URI Class Initialized
DEBUG - 2020-04-18 17:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:27:57 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:27:57 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:27:57 --> Router Class Initialized
INFO - 2020-04-18 17:27:57 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:27:57 --> Output Class Initialized
INFO - 2020-04-18 17:27:57 --> Final output sent to browser
INFO - 2020-04-18 17:27:57 --> Security Class Initialized
DEBUG - 2020-04-18 17:27:57 --> Total execution time: 3.2252
INFO - 2020-04-18 17:27:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-18 17:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:27:57 --> Controller Class Initialized
INFO - 2020-04-18 17:27:57 --> Input Class Initialized
INFO - 2020-04-18 17:27:57 --> Language Class Initialized
INFO - 2020-04-18 17:27:57 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:27:57 --> Loader Class Initialized
INFO - 2020-04-18 17:27:57 --> Helper loaded: url_helper
INFO - 2020-04-18 17:27:57 --> Helper loaded: file_helper
INFO - 2020-04-18 17:27:57 --> Helper loaded: form_helper
INFO - 2020-04-18 17:27:57 --> Database Driver Class Initialized
INFO - 2020-04-18 17:27:57 --> Email Class Initialized
DEBUG - 2020-04-18 17:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:27:57 --> Config Class Initialized
INFO - 2020-04-18 17:27:57 --> Hooks Class Initialized
INFO - 2020-04-18 17:27:57 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:27:57 --> Model "Appsettings_model" initialized
DEBUG - 2020-04-18 17:27:57 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:27:57 --> Utf8 Class Initialized
INFO - 2020-04-18 17:27:57 --> Form Validation Class Initialized
INFO - 2020-04-18 17:27:57 --> URI Class Initialized
INFO - 2020-04-18 17:27:57 --> Upload Class Initialized
INFO - 2020-04-18 17:27:57 --> Router Class Initialized
INFO - 2020-04-18 17:27:58 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:27:58 --> Output Class Initialized
INFO - 2020-04-18 17:27:58 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:27:58 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:27:58 --> Security Class Initialized
INFO - 2020-04-18 17:27:58 --> Final output sent to browser
DEBUG - 2020-04-18 17:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:27:58 --> Input Class Initialized
DEBUG - 2020-04-18 17:27:58 --> Total execution time: 3.1066
INFO - 2020-04-18 17:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:27:58 --> Language Class Initialized
INFO - 2020-04-18 17:27:58 --> Controller Class Initialized
INFO - 2020-04-18 17:27:58 --> Loader Class Initialized
INFO - 2020-04-18 17:27:58 --> Helper loaded: url_helper
INFO - 2020-04-18 17:27:58 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:27:58 --> Helper loaded: file_helper
INFO - 2020-04-18 17:27:58 --> Helper loaded: form_helper
INFO - 2020-04-18 17:27:58 --> Database Driver Class Initialized
INFO - 2020-04-18 17:27:58 --> Email Class Initialized
DEBUG - 2020-04-18 17:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:27:58 --> Config Class Initialized
INFO - 2020-04-18 17:27:58 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:27:58 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:27:58 --> Utf8 Class Initialized
INFO - 2020-04-18 17:27:58 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:27:58 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:27:58 --> URI Class Initialized
INFO - 2020-04-18 17:27:58 --> Router Class Initialized
INFO - 2020-04-18 17:27:58 --> Form Validation Class Initialized
INFO - 2020-04-18 17:27:58 --> Output Class Initialized
INFO - 2020-04-18 17:27:58 --> Upload Class Initialized
INFO - 2020-04-18 17:27:58 --> Security Class Initialized
INFO - 2020-04-18 17:27:58 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
DEBUG - 2020-04-18 17:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:27:58 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:27:58 --> Input Class Initialized
INFO - 2020-04-18 17:27:58 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:27:58 --> Final output sent to browser
INFO - 2020-04-18 17:27:59 --> Language Class Initialized
DEBUG - 2020-04-18 17:27:59 --> Total execution time: 3.5255
INFO - 2020-04-18 17:27:59 --> Loader Class Initialized
INFO - 2020-04-18 17:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:27:59 --> Helper loaded: url_helper
INFO - 2020-04-18 17:27:59 --> Controller Class Initialized
INFO - 2020-04-18 17:27:59 --> Helper loaded: file_helper
INFO - 2020-04-18 17:27:59 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:27:59 --> Helper loaded: form_helper
INFO - 2020-04-18 17:27:59 --> Database Driver Class Initialized
INFO - 2020-04-18 17:27:59 --> Email Class Initialized
DEBUG - 2020-04-18 17:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:27:59 --> Config Class Initialized
INFO - 2020-04-18 17:27:59 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:27:59 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:27:59 --> Utf8 Class Initialized
INFO - 2020-04-18 17:27:59 --> URI Class Initialized
INFO - 2020-04-18 17:27:59 --> Router Class Initialized
INFO - 2020-04-18 17:27:59 --> Output Class Initialized
INFO - 2020-04-18 17:27:59 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:27:59 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:27:59 --> Security Class Initialized
DEBUG - 2020-04-18 17:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:27:59 --> Form Validation Class Initialized
INFO - 2020-04-18 17:27:59 --> Upload Class Initialized
INFO - 2020-04-18 17:27:59 --> Input Class Initialized
INFO - 2020-04-18 17:27:59 --> Language Class Initialized
INFO - 2020-04-18 17:27:59 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:27:59 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:27:59 --> Loader Class Initialized
INFO - 2020-04-18 17:27:59 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:27:59 --> Helper loaded: url_helper
INFO - 2020-04-18 17:27:59 --> Final output sent to browser
INFO - 2020-04-18 17:27:59 --> Helper loaded: file_helper
DEBUG - 2020-04-18 17:27:59 --> Total execution time: 3.9073
INFO - 2020-04-18 17:27:59 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:00 --> Config Class Initialized
INFO - 2020-04-18 17:28:00 --> Controller Class Initialized
INFO - 2020-04-18 17:28:00 --> Config Class Initialized
INFO - 2020-04-18 17:28:00 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:00 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:00 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:00 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:00 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:00 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:00 --> Config Class Initialized
DEBUG - 2020-04-18 17:28:00 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:00 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:00 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:00 --> Utf8 Class Initialized
DEBUG - 2020-04-18 17:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:00 --> URI Class Initialized
INFO - 2020-04-18 17:28:00 --> Config Class Initialized
INFO - 2020-04-18 17:28:00 --> URI Class Initialized
INFO - 2020-04-18 17:28:00 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:00 --> Router Class Initialized
DEBUG - 2020-04-18 17:28:00 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:00 --> Router Class Initialized
INFO - 2020-04-18 17:28:00 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:00 --> Output Class Initialized
DEBUG - 2020-04-18 17:28:00 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:00 --> Output Class Initialized
INFO - 2020-04-18 17:28:00 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:00 --> URI Class Initialized
INFO - 2020-04-18 17:28:00 --> Security Class Initialized
INFO - 2020-04-18 17:28:00 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:00 --> URI Class Initialized
INFO - 2020-04-18 17:28:00 --> Router Class Initialized
INFO - 2020-04-18 17:28:00 --> Input Class Initialized
INFO - 2020-04-18 17:28:00 --> Router Class Initialized
INFO - 2020-04-18 17:28:00 --> Output Class Initialized
DEBUG - 2020-04-18 17:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:00 --> Input Class Initialized
INFO - 2020-04-18 17:28:00 --> Language Class Initialized
INFO - 2020-04-18 17:28:00 --> Security Class Initialized
INFO - 2020-04-18 17:28:00 --> Output Class Initialized
DEBUG - 2020-04-18 17:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:00 --> Language Class Initialized
INFO - 2020-04-18 17:28:00 --> Security Class Initialized
INFO - 2020-04-18 17:28:00 --> Loader Class Initialized
INFO - 2020-04-18 17:28:00 --> Input Class Initialized
INFO - 2020-04-18 17:28:00 --> Helper loaded: url_helper
DEBUG - 2020-04-18 17:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:00 --> Loader Class Initialized
INFO - 2020-04-18 17:28:00 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:00 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:00 --> Input Class Initialized
INFO - 2020-04-18 17:28:00 --> Language Class Initialized
INFO - 2020-04-18 17:28:00 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:00 --> Language Class Initialized
INFO - 2020-04-18 17:28:00 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:01 --> Loader Class Initialized
INFO - 2020-04-18 17:28:01 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:01 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:01 --> Loader Class Initialized
INFO - 2020-04-18 17:28:01 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:01 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:01 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:01 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:01 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:01 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:01 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:01 --> Upload Class Initialized
INFO - 2020-04-18 17:28:01 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:01 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:01 --> Email Class Initialized
INFO - 2020-04-18 17:28:01 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:01 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:01 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:01 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:01 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
DEBUG - 2020-04-18 17:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:01 --> Email Class Initialized
INFO - 2020-04-18 17:28:01 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:01 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
DEBUG - 2020-04-18 17:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:01 --> Email Class Initialized
INFO - 2020-04-18 17:28:01 --> Final output sent to browser
DEBUG - 2020-04-18 17:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-04-18 17:28:01 --> Total execution time: 4.7285
INFO - 2020-04-18 17:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:01 --> Controller Class Initialized
INFO - 2020-04-18 17:28:01 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:01 --> Config Class Initialized
INFO - 2020-04-18 17:28:01 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:01 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:01 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:01 --> URI Class Initialized
INFO - 2020-04-18 17:28:01 --> Router Class Initialized
INFO - 2020-04-18 17:28:01 --> Output Class Initialized
INFO - 2020-04-18 17:28:01 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:01 --> Input Class Initialized
INFO - 2020-04-18 17:28:01 --> Language Class Initialized
INFO - 2020-04-18 17:28:01 --> Loader Class Initialized
INFO - 2020-04-18 17:28:01 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:01 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:01 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:01 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:01 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:01 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:01 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:01 --> Upload Class Initialized
INFO - 2020-04-18 17:28:02 --> Email Class Initialized
INFO - 2020-04-18 17:28:02 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:02 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
DEBUG - 2020-04-18 17:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:02 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:02 --> Final output sent to browser
DEBUG - 2020-04-18 17:28:02 --> Total execution time: 5.1415
INFO - 2020-04-18 17:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:02 --> Controller Class Initialized
INFO - 2020-04-18 17:28:02 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:02 --> Config Class Initialized
INFO - 2020-04-18 17:28:02 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:02 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:02 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:02 --> URI Class Initialized
INFO - 2020-04-18 17:28:02 --> Router Class Initialized
INFO - 2020-04-18 17:28:02 --> Output Class Initialized
INFO - 2020-04-18 17:28:02 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:03 --> Input Class Initialized
INFO - 2020-04-18 17:28:03 --> Language Class Initialized
INFO - 2020-04-18 17:28:03 --> Loader Class Initialized
INFO - 2020-04-18 17:28:03 --> Config Class Initialized
INFO - 2020-04-18 17:28:03 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:03 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:03 --> Helper loaded: file_helper
DEBUG - 2020-04-18 17:28:03 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:03 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:03 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:03 --> URI Class Initialized
INFO - 2020-04-18 17:28:03 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:03 --> Router Class Initialized
INFO - 2020-04-18 17:28:03 --> Email Class Initialized
INFO - 2020-04-18 17:28:03 --> Output Class Initialized
DEBUG - 2020-04-18 17:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:03 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:03 --> Input Class Initialized
INFO - 2020-04-18 17:28:03 --> Language Class Initialized
INFO - 2020-04-18 17:28:03 --> Loader Class Initialized
INFO - 2020-04-18 17:28:03 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:03 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:03 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:03 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:03 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:03 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:03 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:03 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:03 --> Upload Class Initialized
INFO - 2020-04-18 17:28:03 --> Config Class Initialized
INFO - 2020-04-18 17:28:03 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:03 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
DEBUG - 2020-04-18 17:28:03 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:03 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:03 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:03 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:03 --> URI Class Initialized
INFO - 2020-04-18 17:28:04 --> Final output sent to browser
INFO - 2020-04-18 17:28:04 --> Router Class Initialized
DEBUG - 2020-04-18 17:28:04 --> Total execution time: 6.1622
INFO - 2020-04-18 17:28:04 --> Output Class Initialized
INFO - 2020-04-18 17:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:04 --> Controller Class Initialized
INFO - 2020-04-18 17:28:04 --> Security Class Initialized
INFO - 2020-04-18 17:28:04 --> Model "ci_ext_model" initialized
DEBUG - 2020-04-18 17:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:04 --> Input Class Initialized
INFO - 2020-04-18 17:28:04 --> Language Class Initialized
INFO - 2020-04-18 17:28:04 --> Loader Class Initialized
INFO - 2020-04-18 17:28:04 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:04 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:04 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:04 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:04 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:04 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:04 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:04 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:04 --> Upload Class Initialized
INFO - 2020-04-18 17:28:04 --> Config Class Initialized
INFO - 2020-04-18 17:28:04 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:04 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
DEBUG - 2020-04-18 17:28:04 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:04 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:04 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:05 --> URI Class Initialized
INFO - 2020-04-18 17:28:05 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:05 --> Config Class Initialized
INFO - 2020-04-18 17:28:05 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:05 --> Router Class Initialized
INFO - 2020-04-18 17:28:05 --> Final output sent to browser
DEBUG - 2020-04-18 17:28:05 --> Total execution time: 6.6785
INFO - 2020-04-18 17:28:05 --> Output Class Initialized
DEBUG - 2020-04-18 17:28:05 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:05 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:05 --> Security Class Initialized
INFO - 2020-04-18 17:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:05 --> Controller Class Initialized
INFO - 2020-04-18 17:28:05 --> URI Class Initialized
DEBUG - 2020-04-18 17:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:05 --> Input Class Initialized
INFO - 2020-04-18 17:28:05 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:05 --> Router Class Initialized
INFO - 2020-04-18 17:28:05 --> Language Class Initialized
INFO - 2020-04-18 17:28:05 --> Output Class Initialized
INFO - 2020-04-18 17:28:05 --> Loader Class Initialized
INFO - 2020-04-18 17:28:05 --> Security Class Initialized
INFO - 2020-04-18 17:28:05 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:05 --> Config Class Initialized
INFO - 2020-04-18 17:28:05 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:05 --> Helper loaded: file_helper
DEBUG - 2020-04-18 17:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:05 --> Input Class Initialized
DEBUG - 2020-04-18 17:28:05 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:05 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:05 --> Language Class Initialized
INFO - 2020-04-18 17:28:05 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:06 --> URI Class Initialized
INFO - 2020-04-18 17:28:06 --> Loader Class Initialized
INFO - 2020-04-18 17:28:06 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:06 --> Router Class Initialized
INFO - 2020-04-18 17:28:06 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:06 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:06 --> Email Class Initialized
INFO - 2020-04-18 17:28:06 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:06 --> Output Class Initialized
DEBUG - 2020-04-18 17:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:06 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:06 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:06 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:06 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:06 --> Upload Class Initialized
INFO - 2020-04-18 17:28:06 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:06 --> Input Class Initialized
INFO - 2020-04-18 17:28:06 --> Email Class Initialized
INFO - 2020-04-18 17:28:06 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:06 --> Language Class Initialized
DEBUG - 2020-04-18 17:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:06 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:06 --> Loader Class Initialized
INFO - 2020-04-18 17:28:06 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:06 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:06 --> Final output sent to browser
INFO - 2020-04-18 17:28:06 --> Helper loaded: file_helper
DEBUG - 2020-04-18 17:28:06 --> Total execution time: 6.8954
INFO - 2020-04-18 17:28:06 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:06 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:06 --> Controller Class Initialized
INFO - 2020-04-18 17:28:06 --> Email Class Initialized
INFO - 2020-04-18 17:28:06 --> Model "ci_ext_model" initialized
DEBUG - 2020-04-18 17:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:06 --> Config Class Initialized
INFO - 2020-04-18 17:28:06 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:06 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:06 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:06 --> URI Class Initialized
INFO - 2020-04-18 17:28:06 --> Router Class Initialized
INFO - 2020-04-18 17:28:06 --> Output Class Initialized
INFO - 2020-04-18 17:28:06 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:06 --> Input Class Initialized
INFO - 2020-04-18 17:28:06 --> Language Class Initialized
INFO - 2020-04-18 17:28:06 --> Loader Class Initialized
INFO - 2020-04-18 17:28:06 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:06 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:06 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:06 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:06 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:06 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:06 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:06 --> Upload Class Initialized
INFO - 2020-04-18 17:28:06 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:06 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:07 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:07 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:07 --> Final output sent to browser
DEBUG - 2020-04-18 17:28:07 --> Total execution time: 6.7418
INFO - 2020-04-18 17:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:07 --> Controller Class Initialized
INFO - 2020-04-18 17:28:07 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:07 --> Config Class Initialized
INFO - 2020-04-18 17:28:07 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:07 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:07 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:07 --> URI Class Initialized
INFO - 2020-04-18 17:28:07 --> Router Class Initialized
INFO - 2020-04-18 17:28:07 --> Output Class Initialized
INFO - 2020-04-18 17:28:07 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:07 --> Input Class Initialized
INFO - 2020-04-18 17:28:07 --> Language Class Initialized
INFO - 2020-04-18 17:28:07 --> Loader Class Initialized
INFO - 2020-04-18 17:28:07 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:07 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:07 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:07 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:07 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:07 --> Config Class Initialized
INFO - 2020-04-18 17:28:07 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:07 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:07 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:07 --> URI Class Initialized
INFO - 2020-04-18 17:28:08 --> Router Class Initialized
INFO - 2020-04-18 17:28:08 --> Output Class Initialized
INFO - 2020-04-18 17:28:08 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:08 --> Input Class Initialized
INFO - 2020-04-18 17:28:08 --> Language Class Initialized
INFO - 2020-04-18 17:28:08 --> Loader Class Initialized
INFO - 2020-04-18 17:28:08 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:08 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:08 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:08 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:08 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:08 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:08 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:08 --> Email Class Initialized
INFO - 2020-04-18 17:28:08 --> Upload Class Initialized
DEBUG - 2020-04-18 17:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:08 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:08 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:08 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:08 --> Final output sent to browser
DEBUG - 2020-04-18 17:28:08 --> Total execution time: 8.4867
INFO - 2020-04-18 17:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:08 --> Controller Class Initialized
INFO - 2020-04-18 17:28:08 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:08 --> Config Class Initialized
INFO - 2020-04-18 17:28:08 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:09 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:09 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:09 --> URI Class Initialized
INFO - 2020-04-18 17:28:09 --> Router Class Initialized
INFO - 2020-04-18 17:28:09 --> Output Class Initialized
INFO - 2020-04-18 17:28:09 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:09 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:09 --> Security Class Initialized
INFO - 2020-04-18 17:28:09 --> Form Validation Class Initialized
DEBUG - 2020-04-18 17:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:09 --> Upload Class Initialized
INFO - 2020-04-18 17:28:09 --> Config Class Initialized
INFO - 2020-04-18 17:28:09 --> Input Class Initialized
INFO - 2020-04-18 17:28:09 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:09 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:09 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
DEBUG - 2020-04-18 17:28:09 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:09 --> Language Class Initialized
INFO - 2020-04-18 17:28:09 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:09 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:09 --> Loader Class Initialized
INFO - 2020-04-18 17:28:09 --> Final output sent to browser
INFO - 2020-04-18 17:28:09 --> URI Class Initialized
INFO - 2020-04-18 17:28:09 --> Helper loaded: url_helper
DEBUG - 2020-04-18 17:28:09 --> Total execution time: 9.1022
INFO - 2020-04-18 17:28:09 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:09 --> Router Class Initialized
INFO - 2020-04-18 17:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:09 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:09 --> Output Class Initialized
INFO - 2020-04-18 17:28:09 --> Controller Class Initialized
INFO - 2020-04-18 17:28:09 --> Security Class Initialized
INFO - 2020-04-18 17:28:09 --> Database Driver Class Initialized
DEBUG - 2020-04-18 17:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:09 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:09 --> Email Class Initialized
INFO - 2020-04-18 17:28:09 --> Input Class Initialized
DEBUG - 2020-04-18 17:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:09 --> Language Class Initialized
INFO - 2020-04-18 17:28:09 --> Loader Class Initialized
INFO - 2020-04-18 17:28:09 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:09 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:09 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:10 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:10 --> Config Class Initialized
INFO - 2020-04-18 17:28:10 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:10 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:10 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:10 --> Config Class Initialized
DEBUG - 2020-04-18 17:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:10 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:10 --> Config Class Initialized
INFO - 2020-04-18 17:28:10 --> Utf8 Class Initialized
DEBUG - 2020-04-18 17:28:10 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:10 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:10 --> URI Class Initialized
INFO - 2020-04-18 17:28:10 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:10 --> Router Class Initialized
DEBUG - 2020-04-18 17:28:10 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:10 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:10 --> URI Class Initialized
INFO - 2020-04-18 17:28:10 --> Output Class Initialized
INFO - 2020-04-18 17:28:10 --> URI Class Initialized
INFO - 2020-04-18 17:28:10 --> Security Class Initialized
INFO - 2020-04-18 17:28:10 --> Router Class Initialized
DEBUG - 2020-04-18 17:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:10 --> Router Class Initialized
INFO - 2020-04-18 17:28:10 --> Output Class Initialized
INFO - 2020-04-18 17:28:10 --> Input Class Initialized
INFO - 2020-04-18 17:28:10 --> Security Class Initialized
INFO - 2020-04-18 17:28:10 --> Output Class Initialized
INFO - 2020-04-18 17:28:10 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:10 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:10 --> Language Class Initialized
DEBUG - 2020-04-18 17:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:10 --> Security Class Initialized
INFO - 2020-04-18 17:28:10 --> Input Class Initialized
INFO - 2020-04-18 17:28:10 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:10 --> Loader Class Initialized
DEBUG - 2020-04-18 17:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:10 --> Upload Class Initialized
INFO - 2020-04-18 17:28:10 --> Input Class Initialized
INFO - 2020-04-18 17:28:10 --> Language Class Initialized
INFO - 2020-04-18 17:28:10 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:10 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:10 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:10 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:10 --> Language Class Initialized
INFO - 2020-04-18 17:28:10 --> Loader Class Initialized
INFO - 2020-04-18 17:28:10 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:10 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:10 --> Loader Class Initialized
INFO - 2020-04-18 17:28:10 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:10 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:10 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:10 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:10 --> Email Class Initialized
INFO - 2020-04-18 17:28:10 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:10 --> Final output sent to browser
INFO - 2020-04-18 17:28:10 --> Helper loaded: form_helper
DEBUG - 2020-04-18 17:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-04-18 17:28:10 --> Total execution time: 10.2844
INFO - 2020-04-18 17:28:10 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:10 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:10 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:10 --> Controller Class Initialized
INFO - 2020-04-18 17:28:10 --> Email Class Initialized
INFO - 2020-04-18 17:28:10 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-04-18 17:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:10 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:11 --> Config Class Initialized
INFO - 2020-04-18 17:28:11 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:11 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:11 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:11 --> URI Class Initialized
INFO - 2020-04-18 17:28:11 --> Router Class Initialized
INFO - 2020-04-18 17:28:11 --> Output Class Initialized
INFO - 2020-04-18 17:28:11 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:11 --> Input Class Initialized
INFO - 2020-04-18 17:28:11 --> Language Class Initialized
INFO - 2020-04-18 17:28:11 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:11 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:11 --> Loader Class Initialized
INFO - 2020-04-18 17:28:11 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:11 --> Config Class Initialized
INFO - 2020-04-18 17:28:11 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:11 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:11 --> Upload Class Initialized
DEBUG - 2020-04-18 17:28:11 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:11 --> Config Class Initialized
INFO - 2020-04-18 17:28:11 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:11 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:11 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:11 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:11 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:11 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:11 --> URI Class Initialized
INFO - 2020-04-18 17:28:11 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
DEBUG - 2020-04-18 17:28:11 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:11 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:11 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:11 --> Final output sent to browser
INFO - 2020-04-18 17:28:11 --> Email Class Initialized
INFO - 2020-04-18 17:28:11 --> Config Class Initialized
INFO - 2020-04-18 17:28:11 --> Router Class Initialized
DEBUG - 2020-04-18 17:28:11 --> Total execution time: 10.4023
DEBUG - 2020-04-18 17:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:12 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:12 --> URI Class Initialized
INFO - 2020-04-18 17:28:12 --> Output Class Initialized
INFO - 2020-04-18 17:28:12 --> Controller Class Initialized
INFO - 2020-04-18 17:28:12 --> Config Class Initialized
INFO - 2020-04-18 17:28:12 --> Security Class Initialized
INFO - 2020-04-18 17:28:12 --> Router Class Initialized
DEBUG - 2020-04-18 17:28:12 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:12 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:12 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:12 --> Model "ci_ext_model" initialized
DEBUG - 2020-04-18 17:28:12 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:12 --> Config Class Initialized
DEBUG - 2020-04-18 17:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:12 --> Output Class Initialized
INFO - 2020-04-18 17:28:12 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:12 --> URI Class Initialized
INFO - 2020-04-18 17:28:12 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:12 --> Input Class Initialized
INFO - 2020-04-18 17:28:12 --> Security Class Initialized
INFO - 2020-04-18 17:28:12 --> Language Class Initialized
DEBUG - 2020-04-18 17:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-18 17:28:12 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:12 --> Router Class Initialized
INFO - 2020-04-18 17:28:12 --> Config Class Initialized
INFO - 2020-04-18 17:28:12 --> URI Class Initialized
INFO - 2020-04-18 17:28:12 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:12 --> Input Class Initialized
INFO - 2020-04-18 17:28:12 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:12 --> Output Class Initialized
INFO - 2020-04-18 17:28:12 --> Router Class Initialized
INFO - 2020-04-18 17:28:12 --> Loader Class Initialized
INFO - 2020-04-18 17:28:12 --> URI Class Initialized
INFO - 2020-04-18 17:28:12 --> Language Class Initialized
INFO - 2020-04-18 17:28:12 --> Output Class Initialized
DEBUG - 2020-04-18 17:28:12 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:12 --> Security Class Initialized
INFO - 2020-04-18 17:28:12 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:12 --> Utf8 Class Initialized
DEBUG - 2020-04-18 17:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:12 --> Router Class Initialized
INFO - 2020-04-18 17:28:12 --> Security Class Initialized
INFO - 2020-04-18 17:28:12 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:12 --> Loader Class Initialized
DEBUG - 2020-04-18 17:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:12 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:12 --> Output Class Initialized
INFO - 2020-04-18 17:28:12 --> Input Class Initialized
INFO - 2020-04-18 17:28:12 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:12 --> URI Class Initialized
INFO - 2020-04-18 17:28:12 --> Input Class Initialized
INFO - 2020-04-18 17:28:12 --> Security Class Initialized
INFO - 2020-04-18 17:28:12 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:12 --> Router Class Initialized
INFO - 2020-04-18 17:28:12 --> Language Class Initialized
INFO - 2020-04-18 17:28:12 --> Database Driver Class Initialized
DEBUG - 2020-04-18 17:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:12 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:12 --> Output Class Initialized
INFO - 2020-04-18 17:28:12 --> Language Class Initialized
INFO - 2020-04-18 17:28:12 --> Email Class Initialized
INFO - 2020-04-18 17:28:12 --> Loader Class Initialized
INFO - 2020-04-18 17:28:12 --> Input Class Initialized
INFO - 2020-04-18 17:28:12 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:12 --> Language Class Initialized
INFO - 2020-04-18 17:28:12 --> Helper loaded: url_helper
DEBUG - 2020-04-18 17:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:12 --> Loader Class Initialized
INFO - 2020-04-18 17:28:12 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:12 --> Input Class Initialized
INFO - 2020-04-18 17:28:12 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:12 --> Loader Class Initialized
INFO - 2020-04-18 17:28:12 --> Language Class Initialized
INFO - 2020-04-18 17:28:12 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:12 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:12 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:12 --> Email Class Initialized
INFO - 2020-04-18 17:28:12 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:12 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:12 --> Loader Class Initialized
INFO - 2020-04-18 17:28:12 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:12 --> Helper loaded: url_helper
DEBUG - 2020-04-18 17:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:12 --> Email Class Initialized
INFO - 2020-04-18 17:28:12 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:12 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:12 --> Helper loaded: file_helper
DEBUG - 2020-04-18 17:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:12 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:12 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:12 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:12 --> Email Class Initialized
INFO - 2020-04-18 17:28:12 --> Email Class Initialized
INFO - 2020-04-18 17:28:12 --> Database Driver Class Initialized
DEBUG - 2020-04-18 17:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-04-18 17:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:12 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:12 --> Config Class Initialized
INFO - 2020-04-18 17:28:13 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:13 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:13 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:13 --> URI Class Initialized
INFO - 2020-04-18 17:28:13 --> Router Class Initialized
INFO - 2020-04-18 17:28:13 --> Output Class Initialized
INFO - 2020-04-18 17:28:13 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:13 --> Input Class Initialized
INFO - 2020-04-18 17:28:13 --> Config Class Initialized
INFO - 2020-04-18 17:28:13 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:13 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:13 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:13 --> Language Class Initialized
INFO - 2020-04-18 17:28:13 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:13 --> Loader Class Initialized
DEBUG - 2020-04-18 17:28:13 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:13 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:13 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:13 --> Upload Class Initialized
INFO - 2020-04-18 17:28:13 --> URI Class Initialized
INFO - 2020-04-18 17:28:13 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:13 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:13 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:13 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:13 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:13 --> Router Class Initialized
INFO - 2020-04-18 17:28:13 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:13 --> Final output sent to browser
INFO - 2020-04-18 17:28:13 --> Output Class Initialized
INFO - 2020-04-18 17:28:13 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:13 --> Total execution time: 11.1230
DEBUG - 2020-04-18 17:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:13 --> Security Class Initialized
INFO - 2020-04-18 17:28:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-18 17:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:13 --> Input Class Initialized
INFO - 2020-04-18 17:28:13 --> Controller Class Initialized
INFO - 2020-04-18 17:28:13 --> Language Class Initialized
INFO - 2020-04-18 17:28:13 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:14 --> Loader Class Initialized
INFO - 2020-04-18 17:28:14 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:14 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:14 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:14 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:14 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:14 --> Config Class Initialized
INFO - 2020-04-18 17:28:14 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:14 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:14 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:14 --> Form Validation Class Initialized
DEBUG - 2020-04-18 17:28:14 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:14 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:14 --> Upload Class Initialized
INFO - 2020-04-18 17:28:14 --> URI Class Initialized
INFO - 2020-04-18 17:28:14 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:14 --> Router Class Initialized
INFO - 2020-04-18 17:28:14 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:14 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:14 --> Output Class Initialized
INFO - 2020-04-18 17:28:14 --> Final output sent to browser
INFO - 2020-04-18 17:28:14 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:14 --> Total execution time: 11.5153
DEBUG - 2020-04-18 17:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:14 --> Input Class Initialized
INFO - 2020-04-18 17:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:14 --> Controller Class Initialized
INFO - 2020-04-18 17:28:14 --> Language Class Initialized
INFO - 2020-04-18 17:28:14 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:14 --> Loader Class Initialized
INFO - 2020-04-18 17:28:14 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:14 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:14 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:15 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:15 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:15 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:15 --> Config Class Initialized
INFO - 2020-04-18 17:28:15 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:15 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:15 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:15 --> Upload Class Initialized
DEBUG - 2020-04-18 17:28:15 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:15 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:15 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:15 --> URI Class Initialized
INFO - 2020-04-18 17:28:15 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:15 --> Router Class Initialized
INFO - 2020-04-18 17:28:15 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:15 --> Final output sent to browser
INFO - 2020-04-18 17:28:15 --> Output Class Initialized
DEBUG - 2020-04-18 17:28:15 --> Total execution time: 11.7919
INFO - 2020-04-18 17:28:15 --> Security Class Initialized
INFO - 2020-04-18 17:28:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-18 17:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:15 --> Input Class Initialized
INFO - 2020-04-18 17:28:15 --> Controller Class Initialized
INFO - 2020-04-18 17:28:15 --> Language Class Initialized
INFO - 2020-04-18 17:28:15 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:15 --> Loader Class Initialized
INFO - 2020-04-18 17:28:15 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:15 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:15 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:15 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:15 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:16 --> Config Class Initialized
INFO - 2020-04-18 17:28:16 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:16 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:16 --> Model "Appsettings_model" initialized
DEBUG - 2020-04-18 17:28:16 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:16 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:16 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:16 --> Config Class Initialized
INFO - 2020-04-18 17:28:16 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:16 --> URI Class Initialized
INFO - 2020-04-18 17:28:16 --> Upload Class Initialized
DEBUG - 2020-04-18 17:28:16 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:16 --> Router Class Initialized
INFO - 2020-04-18 17:28:16 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:16 --> Output Class Initialized
INFO - 2020-04-18 17:28:16 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:16 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:16 --> Security Class Initialized
INFO - 2020-04-18 17:28:16 --> URI Class Initialized
INFO - 2020-04-18 17:28:16 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:16 --> Router Class Initialized
DEBUG - 2020-04-18 17:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:16 --> Final output sent to browser
INFO - 2020-04-18 17:28:16 --> Input Class Initialized
INFO - 2020-04-18 17:28:16 --> Language Class Initialized
INFO - 2020-04-18 17:28:16 --> Output Class Initialized
INFO - 2020-04-18 17:28:16 --> Security Class Initialized
INFO - 2020-04-18 17:28:16 --> Loader Class Initialized
DEBUG - 2020-04-18 17:28:16 --> Total execution time: 12.0055
INFO - 2020-04-18 17:28:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-18 17:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:16 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:16 --> Input Class Initialized
INFO - 2020-04-18 17:28:16 --> Controller Class Initialized
INFO - 2020-04-18 17:28:16 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:16 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:16 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:16 --> Language Class Initialized
INFO - 2020-04-18 17:28:16 --> Loader Class Initialized
INFO - 2020-04-18 17:28:16 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:16 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:17 --> Email Class Initialized
INFO - 2020-04-18 17:28:17 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:17 --> Helper loaded: form_helper
DEBUG - 2020-04-18 17:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:17 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:17 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:17 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:17 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:17 --> Config Class Initialized
INFO - 2020-04-18 17:28:17 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:17 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:17 --> Upload Class Initialized
DEBUG - 2020-04-18 17:28:17 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:17 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:17 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:17 --> URI Class Initialized
INFO - 2020-04-18 17:28:17 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:17 --> Router Class Initialized
INFO - 2020-04-18 17:28:17 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:17 --> Output Class Initialized
INFO - 2020-04-18 17:28:17 --> Final output sent to browser
INFO - 2020-04-18 17:28:17 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:17 --> Total execution time: 12.4501
DEBUG - 2020-04-18 17:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:17 --> Input Class Initialized
INFO - 2020-04-18 17:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:17 --> Controller Class Initialized
INFO - 2020-04-18 17:28:17 --> Language Class Initialized
INFO - 2020-04-18 17:28:17 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:17 --> Loader Class Initialized
INFO - 2020-04-18 17:28:17 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:17 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:17 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:17 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:18 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:18 --> Config Class Initialized
INFO - 2020-04-18 17:28:18 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:18 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:18 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:18 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:18 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:18 --> URI Class Initialized
INFO - 2020-04-18 17:28:18 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:18 --> Router Class Initialized
INFO - 2020-04-18 17:28:18 --> Upload Class Initialized
INFO - 2020-04-18 17:28:18 --> Output Class Initialized
INFO - 2020-04-18 17:28:18 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:18 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:18 --> Security Class Initialized
INFO - 2020-04-18 17:28:18 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
DEBUG - 2020-04-18 17:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:18 --> Final output sent to browser
DEBUG - 2020-04-18 17:28:18 --> Total execution time: 12.5707
INFO - 2020-04-18 17:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:18 --> Controller Class Initialized
INFO - 2020-04-18 17:28:18 --> Input Class Initialized
INFO - 2020-04-18 17:28:18 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:18 --> Language Class Initialized
INFO - 2020-04-18 17:28:18 --> Loader Class Initialized
INFO - 2020-04-18 17:28:18 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:18 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:18 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:18 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:18 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:19 --> Config Class Initialized
INFO - 2020-04-18 17:28:19 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:19 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:19 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:19 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:19 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:19 --> URI Class Initialized
INFO - 2020-04-18 17:28:19 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:19 --> Router Class Initialized
INFO - 2020-04-18 17:28:19 --> Upload Class Initialized
INFO - 2020-04-18 17:28:19 --> Output Class Initialized
INFO - 2020-04-18 17:28:19 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:19 --> Security Class Initialized
INFO - 2020-04-18 17:28:19 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
DEBUG - 2020-04-18 17:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:19 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:19 --> Input Class Initialized
INFO - 2020-04-18 17:28:19 --> Final output sent to browser
INFO - 2020-04-18 17:28:19 --> Language Class Initialized
DEBUG - 2020-04-18 17:28:19 --> Total execution time: 12.7748
INFO - 2020-04-18 17:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:19 --> Loader Class Initialized
INFO - 2020-04-18 17:28:19 --> Controller Class Initialized
INFO - 2020-04-18 17:28:19 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:19 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:19 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:19 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:19 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:19 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:19 --> Config Class Initialized
INFO - 2020-04-18 17:28:19 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:20 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:20 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:20 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:20 --> Upload Class Initialized
INFO - 2020-04-18 17:28:20 --> Config Class Initialized
INFO - 2020-04-18 17:28:20 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:20 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:20 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:20 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:20 --> Config Class Initialized
DEBUG - 2020-04-18 17:28:20 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:20 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:20 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:20 --> URI Class Initialized
INFO - 2020-04-18 17:28:20 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:20 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:20 --> URI Class Initialized
DEBUG - 2020-04-18 17:28:20 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:20 --> Router Class Initialized
INFO - 2020-04-18 17:28:20 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:20 --> Final output sent to browser
INFO - 2020-04-18 17:28:20 --> Router Class Initialized
INFO - 2020-04-18 17:28:20 --> Output Class Initialized
INFO - 2020-04-18 17:28:20 --> URI Class Initialized
INFO - 2020-04-18 17:28:20 --> Output Class Initialized
INFO - 2020-04-18 17:28:20 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:20 --> Router Class Initialized
INFO - 2020-04-18 17:28:20 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:20 --> Total execution time: 13.2842
DEBUG - 2020-04-18 17:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:20 --> Output Class Initialized
INFO - 2020-04-18 17:28:20 --> Input Class Initialized
INFO - 2020-04-18 17:28:20 --> Input Class Initialized
INFO - 2020-04-18 17:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:20 --> Language Class Initialized
INFO - 2020-04-18 17:28:20 --> Security Class Initialized
INFO - 2020-04-18 17:28:20 --> Controller Class Initialized
INFO - 2020-04-18 17:28:20 --> Language Class Initialized
DEBUG - 2020-04-18 17:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:20 --> Loader Class Initialized
INFO - 2020-04-18 17:28:20 --> Input Class Initialized
INFO - 2020-04-18 17:28:20 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:20 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:20 --> Loader Class Initialized
INFO - 2020-04-18 17:28:20 --> Language Class Initialized
INFO - 2020-04-18 17:28:20 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:20 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:20 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:20 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:20 --> Loader Class Initialized
INFO - 2020-04-18 17:28:20 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:20 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:21 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:21 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:21 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:21 --> Email Class Initialized
INFO - 2020-04-18 17:28:21 --> Helper loaded: form_helper
DEBUG - 2020-04-18 17:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:21 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:21 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:21 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:21 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:21 --> Config Class Initialized
INFO - 2020-04-18 17:28:21 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:21 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:21 --> Form Validation Class Initialized
DEBUG - 2020-04-18 17:28:21 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:21 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:21 --> Upload Class Initialized
INFO - 2020-04-18 17:28:21 --> URI Class Initialized
INFO - 2020-04-18 17:28:21 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:21 --> Router Class Initialized
INFO - 2020-04-18 17:28:21 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:21 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:21 --> Output Class Initialized
INFO - 2020-04-18 17:28:21 --> Final output sent to browser
DEBUG - 2020-04-18 17:28:21 --> Total execution time: 13.7678
INFO - 2020-04-18 17:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:21 --> Security Class Initialized
INFO - 2020-04-18 17:28:21 --> Controller Class Initialized
DEBUG - 2020-04-18 17:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:21 --> Input Class Initialized
INFO - 2020-04-18 17:28:21 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:21 --> Language Class Initialized
INFO - 2020-04-18 17:28:21 --> Loader Class Initialized
INFO - 2020-04-18 17:28:22 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:22 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:22 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:22 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:22 --> Email Class Initialized
INFO - 2020-04-18 17:28:22 --> Config Class Initialized
DEBUG - 2020-04-18 17:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:22 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:22 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:22 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:22 --> URI Class Initialized
INFO - 2020-04-18 17:28:22 --> Router Class Initialized
INFO - 2020-04-18 17:28:22 --> Output Class Initialized
INFO - 2020-04-18 17:28:22 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:22 --> Input Class Initialized
INFO - 2020-04-18 17:28:22 --> Language Class Initialized
INFO - 2020-04-18 17:28:22 --> Loader Class Initialized
INFO - 2020-04-18 17:28:22 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:22 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:22 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:22 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:22 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:22 --> Config Class Initialized
INFO - 2020-04-18 17:28:22 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:22 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:22 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:22 --> URI Class Initialized
INFO - 2020-04-18 17:28:22 --> Router Class Initialized
INFO - 2020-04-18 17:28:22 --> Output Class Initialized
INFO - 2020-04-18 17:28:22 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:23 --> Input Class Initialized
INFO - 2020-04-18 17:28:23 --> Language Class Initialized
INFO - 2020-04-18 17:28:23 --> Loader Class Initialized
INFO - 2020-04-18 17:28:23 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:23 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:23 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:23 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:23 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:23 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:23 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:23 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:23 --> Upload Class Initialized
INFO - 2020-04-18 17:28:23 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:23 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:23 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:23 --> Final output sent to browser
DEBUG - 2020-04-18 17:28:23 --> Total execution time: 14.4502
INFO - 2020-04-18 17:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:23 --> Controller Class Initialized
INFO - 2020-04-18 17:28:23 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:23 --> Config Class Initialized
INFO - 2020-04-18 17:28:23 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:23 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:23 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:23 --> URI Class Initialized
INFO - 2020-04-18 17:28:24 --> Router Class Initialized
INFO - 2020-04-18 17:28:24 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:24 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:24 --> Output Class Initialized
INFO - 2020-04-18 17:28:24 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:24 --> Upload Class Initialized
INFO - 2020-04-18 17:28:24 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:24 --> Input Class Initialized
INFO - 2020-04-18 17:28:24 --> Language Class Initialized
INFO - 2020-04-18 17:28:24 --> Loader Class Initialized
INFO - 2020-04-18 17:28:24 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:24 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:24 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:24 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:24 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:24 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:24 --> Config Class Initialized
INFO - 2020-04-18 17:28:24 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:24 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:24 --> Final output sent to browser
INFO - 2020-04-18 17:28:24 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:24 --> Total execution time: 15.3565
DEBUG - 2020-04-18 17:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-04-18 17:28:24 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:24 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:24 --> Controller Class Initialized
INFO - 2020-04-18 17:28:24 --> URI Class Initialized
INFO - 2020-04-18 17:28:24 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:24 --> Router Class Initialized
INFO - 2020-04-18 17:28:24 --> Output Class Initialized
INFO - 2020-04-18 17:28:24 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:25 --> Input Class Initialized
INFO - 2020-04-18 17:28:25 --> Language Class Initialized
INFO - 2020-04-18 17:28:25 --> Loader Class Initialized
INFO - 2020-04-18 17:28:25 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:25 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:25 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:25 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:25 --> Email Class Initialized
INFO - 2020-04-18 17:28:25 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:25 --> Model "Appsettings_model" initialized
DEBUG - 2020-04-18 17:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:25 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:25 --> Upload Class Initialized
INFO - 2020-04-18 17:28:25 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:25 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:25 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:25 --> Final output sent to browser
DEBUG - 2020-04-18 17:28:25 --> Total execution time: 15.2886
INFO - 2020-04-18 17:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:25 --> Controller Class Initialized
INFO - 2020-04-18 17:28:25 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:25 --> Config Class Initialized
INFO - 2020-04-18 17:28:25 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:25 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:25 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:25 --> URI Class Initialized
INFO - 2020-04-18 17:28:25 --> Router Class Initialized
INFO - 2020-04-18 17:28:25 --> Output Class Initialized
INFO - 2020-04-18 17:28:25 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:25 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:25 --> Input Class Initialized
INFO - 2020-04-18 17:28:25 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:25 --> Language Class Initialized
INFO - 2020-04-18 17:28:25 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:25 --> Upload Class Initialized
INFO - 2020-04-18 17:28:25 --> Loader Class Initialized
INFO - 2020-04-18 17:28:25 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:26 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:26 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:26 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:26 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:26 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:26 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:26 --> Final output sent to browser
INFO - 2020-04-18 17:28:26 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:26 --> Total execution time: 15.8216
DEBUG - 2020-04-18 17:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:26 --> Controller Class Initialized
INFO - 2020-04-18 17:28:26 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:26 --> Config Class Initialized
INFO - 2020-04-18 17:28:26 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:26 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:26 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:26 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:26 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:26 --> URI Class Initialized
INFO - 2020-04-18 17:28:26 --> Router Class Initialized
INFO - 2020-04-18 17:28:26 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:26 --> Upload Class Initialized
INFO - 2020-04-18 17:28:26 --> Output Class Initialized
INFO - 2020-04-18 17:28:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-04-18 17:28:26 --> Security Class Initialized
INFO - 2020-04-18 17:28:26 --> Final output sent to browser
DEBUG - 2020-04-18 17:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:26 --> Input Class Initialized
DEBUG - 2020-04-18 17:28:26 --> Total execution time: 16.3349
INFO - 2020-04-18 17:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:26 --> Language Class Initialized
INFO - 2020-04-18 17:28:26 --> Controller Class Initialized
INFO - 2020-04-18 17:28:26 --> Loader Class Initialized
INFO - 2020-04-18 17:28:26 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:26 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:26 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:26 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:26 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:26 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:27 --> Config Class Initialized
INFO - 2020-04-18 17:28:27 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:27 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:27 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:27 --> Form Validation Class Initialized
DEBUG - 2020-04-18 17:28:27 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:27 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:27 --> Upload Class Initialized
INFO - 2020-04-18 17:28:27 --> URI Class Initialized
INFO - 2020-04-18 17:28:27 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:27 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:27 --> Router Class Initialized
INFO - 2020-04-18 17:28:27 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:27 --> Output Class Initialized
INFO - 2020-04-18 17:28:27 --> Final output sent to browser
INFO - 2020-04-18 17:28:27 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:27 --> Total execution time: 16.2815
DEBUG - 2020-04-18 17:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:27 --> Input Class Initialized
INFO - 2020-04-18 17:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:27 --> Controller Class Initialized
INFO - 2020-04-18 17:28:27 --> Language Class Initialized
INFO - 2020-04-18 17:28:27 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:27 --> Loader Class Initialized
INFO - 2020-04-18 17:28:27 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:27 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:27 --> Config Class Initialized
INFO - 2020-04-18 17:28:27 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:27 --> Helper loaded: form_helper
DEBUG - 2020-04-18 17:28:27 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:27 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:27 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:27 --> Email Class Initialized
INFO - 2020-04-18 17:28:27 --> URI Class Initialized
DEBUG - 2020-04-18 17:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:27 --> Router Class Initialized
INFO - 2020-04-18 17:28:27 --> Output Class Initialized
INFO - 2020-04-18 17:28:27 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:27 --> Input Class Initialized
INFO - 2020-04-18 17:28:27 --> Language Class Initialized
INFO - 2020-04-18 17:28:27 --> Loader Class Initialized
INFO - 2020-04-18 17:28:27 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:27 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:27 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:27 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:28 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:28 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:28 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:28 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:28 --> Upload Class Initialized
INFO - 2020-04-18 17:28:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-04-18 17:28:28 --> Final output sent to browser
DEBUG - 2020-04-18 17:28:28 --> Total execution time: 16.6067
INFO - 2020-04-18 17:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:28 --> Controller Class Initialized
INFO - 2020-04-18 17:28:28 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:28 --> Config Class Initialized
INFO - 2020-04-18 17:28:28 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:28 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:28 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:28 --> URI Class Initialized
INFO - 2020-04-18 17:28:28 --> Router Class Initialized
INFO - 2020-04-18 17:28:28 --> Output Class Initialized
INFO - 2020-04-18 17:28:28 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:28 --> Input Class Initialized
INFO - 2020-04-18 17:28:28 --> Language Class Initialized
INFO - 2020-04-18 17:28:28 --> Loader Class Initialized
INFO - 2020-04-18 17:28:28 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:28 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:28 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:28 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:28 --> Config Class Initialized
INFO - 2020-04-18 17:28:28 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:28 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:28 --> Database Driver Class Initialized
DEBUG - 2020-04-18 17:28:29 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:29 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:29 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:29 --> Upload Class Initialized
INFO - 2020-04-18 17:28:29 --> Email Class Initialized
INFO - 2020-04-18 17:28:29 --> URI Class Initialized
INFO - 2020-04-18 17:28:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2020-04-18 17:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:29 --> Final output sent to browser
INFO - 2020-04-18 17:28:29 --> Router Class Initialized
DEBUG - 2020-04-18 17:28:29 --> Total execution time: 17.3983
INFO - 2020-04-18 17:28:29 --> Output Class Initialized
INFO - 2020-04-18 17:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:29 --> Security Class Initialized
INFO - 2020-04-18 17:28:29 --> Controller Class Initialized
DEBUG - 2020-04-18 17:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:29 --> Input Class Initialized
INFO - 2020-04-18 17:28:29 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:29 --> Language Class Initialized
INFO - 2020-04-18 17:28:29 --> Loader Class Initialized
INFO - 2020-04-18 17:28:29 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:29 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:29 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:29 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:29 --> Email Class Initialized
INFO - 2020-04-18 17:28:29 --> Config Class Initialized
INFO - 2020-04-18 17:28:29 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-04-18 17:28:29 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:29 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:29 --> URI Class Initialized
INFO - 2020-04-18 17:28:29 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:29 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:29 --> Router Class Initialized
INFO - 2020-04-18 17:28:29 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:29 --> Output Class Initialized
INFO - 2020-04-18 17:28:29 --> Upload Class Initialized
INFO - 2020-04-18 17:28:29 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:30 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:30 --> Input Class Initialized
INFO - 2020-04-18 17:28:30 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:30 --> Language Class Initialized
INFO - 2020-04-18 17:28:30 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:30 --> Final output sent to browser
INFO - 2020-04-18 17:28:30 --> Loader Class Initialized
DEBUG - 2020-04-18 17:28:30 --> Total execution time: 18.1425
INFO - 2020-04-18 17:28:30 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:30 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:30 --> Controller Class Initialized
INFO - 2020-04-18 17:28:30 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:30 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:30 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:30 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:30 --> Config Class Initialized
INFO - 2020-04-18 17:28:30 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:30 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:30 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:30 --> URI Class Initialized
INFO - 2020-04-18 17:28:30 --> Router Class Initialized
INFO - 2020-04-18 17:28:30 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:30 --> Output Class Initialized
INFO - 2020-04-18 17:28:30 --> Security Class Initialized
INFO - 2020-04-18 17:28:30 --> Model "Appsettings_model" initialized
DEBUG - 2020-04-18 17:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:30 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:30 --> Input Class Initialized
INFO - 2020-04-18 17:28:30 --> Upload Class Initialized
INFO - 2020-04-18 17:28:30 --> Language Class Initialized
INFO - 2020-04-18 17:28:30 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:30 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:30 --> Loader Class Initialized
INFO - 2020-04-18 17:28:30 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:30 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:30 --> Final output sent to browser
INFO - 2020-04-18 17:28:30 --> Helper loaded: file_helper
DEBUG - 2020-04-18 17:28:30 --> Total execution time: 18.7059
INFO - 2020-04-18 17:28:30 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:30 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:30 --> Controller Class Initialized
INFO - 2020-04-18 17:28:30 --> Email Class Initialized
INFO - 2020-04-18 17:28:30 --> Model "ci_ext_model" initialized
DEBUG - 2020-04-18 17:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:31 --> Config Class Initialized
INFO - 2020-04-18 17:28:31 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:31 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:31 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:31 --> URI Class Initialized
INFO - 2020-04-18 17:28:31 --> Router Class Initialized
INFO - 2020-04-18 17:28:31 --> Output Class Initialized
INFO - 2020-04-18 17:28:31 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:31 --> Input Class Initialized
INFO - 2020-04-18 17:28:31 --> Language Class Initialized
INFO - 2020-04-18 17:28:31 --> Loader Class Initialized
INFO - 2020-04-18 17:28:31 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:31 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:31 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:31 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:31 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:31 --> Config Class Initialized
INFO - 2020-04-18 17:28:31 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:31 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:31 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:31 --> URI Class Initialized
INFO - 2020-04-18 17:28:31 --> Router Class Initialized
INFO - 2020-04-18 17:28:31 --> Output Class Initialized
INFO - 2020-04-18 17:28:31 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:31 --> Input Class Initialized
INFO - 2020-04-18 17:28:31 --> Language Class Initialized
INFO - 2020-04-18 17:28:31 --> Loader Class Initialized
INFO - 2020-04-18 17:28:31 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:31 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:32 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:32 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:32 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:32 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:32 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:32 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:32 --> Upload Class Initialized
INFO - 2020-04-18 17:28:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-04-18 17:28:32 --> Final output sent to browser
DEBUG - 2020-04-18 17:28:32 --> Total execution time: 20.2164
INFO - 2020-04-18 17:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:32 --> Controller Class Initialized
INFO - 2020-04-18 17:28:32 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:32 --> Config Class Initialized
INFO - 2020-04-18 17:28:32 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:32 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:32 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:32 --> URI Class Initialized
INFO - 2020-04-18 17:28:32 --> Router Class Initialized
INFO - 2020-04-18 17:28:33 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:33 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:33 --> Output Class Initialized
INFO - 2020-04-18 17:28:33 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:33 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:33 --> Upload Class Initialized
INFO - 2020-04-18 17:28:33 --> Input Class Initialized
INFO - 2020-04-18 17:28:33 --> Language Class Initialized
INFO - 2020-04-18 17:28:33 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:33 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:33 --> Loader Class Initialized
INFO - 2020-04-18 17:28:33 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:33 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:33 --> Final output sent to browser
INFO - 2020-04-18 17:28:33 --> Helper loaded: file_helper
DEBUG - 2020-04-18 17:28:33 --> Total execution time: 20.9010
INFO - 2020-04-18 17:28:33 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:33 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:33 --> Controller Class Initialized
INFO - 2020-04-18 17:28:33 --> Email Class Initialized
INFO - 2020-04-18 17:28:33 --> Model "ci_ext_model" initialized
DEBUG - 2020-04-18 17:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:33 --> Config Class Initialized
INFO - 2020-04-18 17:28:33 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:33 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:33 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:33 --> URI Class Initialized
INFO - 2020-04-18 17:28:33 --> Router Class Initialized
INFO - 2020-04-18 17:28:33 --> Output Class Initialized
INFO - 2020-04-18 17:28:33 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:33 --> Input Class Initialized
INFO - 2020-04-18 17:28:33 --> Language Class Initialized
INFO - 2020-04-18 17:28:33 --> Loader Class Initialized
INFO - 2020-04-18 17:28:33 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:33 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:33 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:33 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:33 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:33 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:33 --> Upload Class Initialized
INFO - 2020-04-18 17:28:33 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:33 --> Email Class Initialized
INFO - 2020-04-18 17:28:33 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:33 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
DEBUG - 2020-04-18 17:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:34 --> Config Class Initialized
INFO - 2020-04-18 17:28:34 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:34 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:34 --> Final output sent to browser
DEBUG - 2020-04-18 17:28:34 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:34 --> Utf8 Class Initialized
DEBUG - 2020-04-18 17:28:34 --> Total execution time: 21.0801
INFO - 2020-04-18 17:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:34 --> URI Class Initialized
INFO - 2020-04-18 17:28:34 --> Controller Class Initialized
INFO - 2020-04-18 17:28:34 --> Router Class Initialized
INFO - 2020-04-18 17:28:34 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:34 --> Output Class Initialized
INFO - 2020-04-18 17:28:34 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:34 --> Input Class Initialized
INFO - 2020-04-18 17:28:34 --> Language Class Initialized
INFO - 2020-04-18 17:28:34 --> Loader Class Initialized
INFO - 2020-04-18 17:28:34 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:34 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:34 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:34 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:34 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:34 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:34 --> Config Class Initialized
INFO - 2020-04-18 17:28:34 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:34 --> Model "Appsettings_model" initialized
DEBUG - 2020-04-18 17:28:34 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:34 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:34 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:34 --> Upload Class Initialized
INFO - 2020-04-18 17:28:34 --> URI Class Initialized
INFO - 2020-04-18 17:28:34 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:34 --> Router Class Initialized
INFO - 2020-04-18 17:28:34 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:34 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:34 --> Output Class Initialized
INFO - 2020-04-18 17:28:34 --> Final output sent to browser
INFO - 2020-04-18 17:28:34 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:34 --> Total execution time: 21.4376
INFO - 2020-04-18 17:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:35 --> Controller Class Initialized
DEBUG - 2020-04-18 17:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:35 --> Input Class Initialized
INFO - 2020-04-18 17:28:35 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:35 --> Language Class Initialized
INFO - 2020-04-18 17:28:35 --> Loader Class Initialized
INFO - 2020-04-18 17:28:35 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:35 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:35 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:35 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:35 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:35 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:35 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:35 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:35 --> Upload Class Initialized
INFO - 2020-04-18 17:28:35 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:35 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:35 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:35 --> Final output sent to browser
DEBUG - 2020-04-18 17:28:35 --> Total execution time: 21.4876
INFO - 2020-04-18 17:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:35 --> Controller Class Initialized
INFO - 2020-04-18 17:28:35 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:36 --> Config Class Initialized
INFO - 2020-04-18 17:28:36 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:36 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:36 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:36 --> URI Class Initialized
INFO - 2020-04-18 17:28:36 --> Router Class Initialized
INFO - 2020-04-18 17:28:36 --> Output Class Initialized
INFO - 2020-04-18 17:28:36 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:36 --> Input Class Initialized
INFO - 2020-04-18 17:28:36 --> Language Class Initialized
INFO - 2020-04-18 17:28:36 --> Loader Class Initialized
INFO - 2020-04-18 17:28:36 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:36 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:36 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:36 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:36 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:36 --> Config Class Initialized
INFO - 2020-04-18 17:28:36 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:36 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:36 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:36 --> URI Class Initialized
INFO - 2020-04-18 17:28:36 --> Config Class Initialized
INFO - 2020-04-18 17:28:36 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:36 --> Router Class Initialized
INFO - 2020-04-18 17:28:36 --> Output Class Initialized
DEBUG - 2020-04-18 17:28:36 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:36 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:36 --> Security Class Initialized
INFO - 2020-04-18 17:28:36 --> URI Class Initialized
DEBUG - 2020-04-18 17:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:36 --> Router Class Initialized
INFO - 2020-04-18 17:28:36 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:36 --> Input Class Initialized
INFO - 2020-04-18 17:28:37 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:37 --> Output Class Initialized
INFO - 2020-04-18 17:28:37 --> Language Class Initialized
INFO - 2020-04-18 17:28:37 --> Security Class Initialized
INFO - 2020-04-18 17:28:37 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:37 --> Loader Class Initialized
INFO - 2020-04-18 17:28:37 --> Helper loaded: url_helper
DEBUG - 2020-04-18 17:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:37 --> Upload Class Initialized
INFO - 2020-04-18 17:28:37 --> Input Class Initialized
INFO - 2020-04-18 17:28:37 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:37 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:37 --> Language Class Initialized
INFO - 2020-04-18 17:28:37 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:37 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:37 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:37 --> Loader Class Initialized
INFO - 2020-04-18 17:28:37 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:37 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:37 --> Email Class Initialized
INFO - 2020-04-18 17:28:37 --> Final output sent to browser
INFO - 2020-04-18 17:28:37 --> Helper loaded: file_helper
DEBUG - 2020-04-18 17:28:37 --> Total execution time: 21.8165
DEBUG - 2020-04-18 17:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:37 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:37 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:37 --> Controller Class Initialized
INFO - 2020-04-18 17:28:37 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:37 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:37 --> Config Class Initialized
INFO - 2020-04-18 17:28:37 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:37 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:37 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:37 --> URI Class Initialized
INFO - 2020-04-18 17:28:37 --> Router Class Initialized
INFO - 2020-04-18 17:28:37 --> Output Class Initialized
INFO - 2020-04-18 17:28:37 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:37 --> Input Class Initialized
INFO - 2020-04-18 17:28:37 --> Language Class Initialized
INFO - 2020-04-18 17:28:37 --> Loader Class Initialized
INFO - 2020-04-18 17:28:37 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:37 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:37 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:37 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:37 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:38 --> Config Class Initialized
INFO - 2020-04-18 17:28:38 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:38 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:38 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:38 --> URI Class Initialized
INFO - 2020-04-18 17:28:38 --> Router Class Initialized
INFO - 2020-04-18 17:28:38 --> Output Class Initialized
INFO - 2020-04-18 17:28:38 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:38 --> Input Class Initialized
INFO - 2020-04-18 17:28:38 --> Language Class Initialized
INFO - 2020-04-18 17:28:38 --> Loader Class Initialized
INFO - 2020-04-18 17:28:38 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:38 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:38 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:38 --> Config Class Initialized
INFO - 2020-04-18 17:28:38 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:38 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:38 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-04-18 17:28:38 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:38 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:38 --> URI Class Initialized
INFO - 2020-04-18 17:28:38 --> Router Class Initialized
INFO - 2020-04-18 17:28:38 --> Output Class Initialized
INFO - 2020-04-18 17:28:38 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:39 --> Input Class Initialized
INFO - 2020-04-18 17:28:39 --> Language Class Initialized
INFO - 2020-04-18 17:28:39 --> Loader Class Initialized
INFO - 2020-04-18 17:28:39 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:39 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:39 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:39 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:39 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:39 --> Config Class Initialized
INFO - 2020-04-18 17:28:39 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:39 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:39 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:39 --> URI Class Initialized
INFO - 2020-04-18 17:28:39 --> Router Class Initialized
INFO - 2020-04-18 17:28:39 --> Output Class Initialized
INFO - 2020-04-18 17:28:39 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:39 --> Input Class Initialized
INFO - 2020-04-18 17:28:39 --> Language Class Initialized
INFO - 2020-04-18 17:28:39 --> Loader Class Initialized
INFO - 2020-04-18 17:28:39 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:39 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:39 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:39 --> Config Class Initialized
INFO - 2020-04-18 17:28:40 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:40 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:40 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:40 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:40 --> Config Class Initialized
INFO - 2020-04-18 17:28:40 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:40 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:40 --> Upload Class Initialized
DEBUG - 2020-04-18 17:28:40 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:40 --> Email Class Initialized
INFO - 2020-04-18 17:28:40 --> Utf8 Class Initialized
DEBUG - 2020-04-18 17:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-04-18 17:28:40 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:40 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:40 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:40 --> URI Class Initialized
INFO - 2020-04-18 17:28:40 --> URI Class Initialized
INFO - 2020-04-18 17:28:40 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:40 --> Router Class Initialized
INFO - 2020-04-18 17:28:40 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:40 --> Router Class Initialized
INFO - 2020-04-18 17:28:40 --> Output Class Initialized
INFO - 2020-04-18 17:28:40 --> Final output sent to browser
INFO - 2020-04-18 17:28:40 --> Output Class Initialized
INFO - 2020-04-18 17:28:40 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:40 --> Total execution time: 24.1614
INFO - 2020-04-18 17:28:40 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:40 --> Input Class Initialized
INFO - 2020-04-18 17:28:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-18 17:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:40 --> Controller Class Initialized
INFO - 2020-04-18 17:28:40 --> Input Class Initialized
INFO - 2020-04-18 17:28:40 --> Language Class Initialized
INFO - 2020-04-18 17:28:40 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:40 --> Language Class Initialized
INFO - 2020-04-18 17:28:40 --> Loader Class Initialized
INFO - 2020-04-18 17:28:40 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:40 --> Loader Class Initialized
INFO - 2020-04-18 17:28:40 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:40 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:40 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:40 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:40 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:40 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:40 --> Email Class Initialized
INFO - 2020-04-18 17:28:40 --> Database Driver Class Initialized
DEBUG - 2020-04-18 17:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:40 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:40 --> Config Class Initialized
INFO - 2020-04-18 17:28:40 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:41 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:41 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:41 --> Form Validation Class Initialized
DEBUG - 2020-04-18 17:28:41 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:41 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:41 --> Upload Class Initialized
INFO - 2020-04-18 17:28:41 --> URI Class Initialized
INFO - 2020-04-18 17:28:41 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:41 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:41 --> Router Class Initialized
INFO - 2020-04-18 17:28:41 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:41 --> Output Class Initialized
INFO - 2020-04-18 17:28:41 --> Final output sent to browser
INFO - 2020-04-18 17:28:41 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:41 --> Total execution time: 24.6685
DEBUG - 2020-04-18 17:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:41 --> Input Class Initialized
INFO - 2020-04-18 17:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:41 --> Controller Class Initialized
INFO - 2020-04-18 17:28:41 --> Language Class Initialized
INFO - 2020-04-18 17:28:41 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:41 --> Loader Class Initialized
INFO - 2020-04-18 17:28:41 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:41 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:41 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:41 --> Config Class Initialized
INFO - 2020-04-18 17:28:41 --> Hooks Class Initialized
INFO - 2020-04-18 17:28:41 --> Database Driver Class Initialized
DEBUG - 2020-04-18 17:28:41 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:41 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:41 --> URI Class Initialized
INFO - 2020-04-18 17:28:41 --> Router Class Initialized
INFO - 2020-04-18 17:28:41 --> Email Class Initialized
INFO - 2020-04-18 17:28:41 --> Output Class Initialized
DEBUG - 2020-04-18 17:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:41 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:41 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:41 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:41 --> Input Class Initialized
INFO - 2020-04-18 17:28:41 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:41 --> Language Class Initialized
INFO - 2020-04-18 17:28:41 --> Upload Class Initialized
INFO - 2020-04-18 17:28:41 --> Loader Class Initialized
INFO - 2020-04-18 17:28:41 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:41 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:41 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:41 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:41 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:41 --> Final output sent to browser
INFO - 2020-04-18 17:28:41 --> Helper loaded: form_helper
DEBUG - 2020-04-18 17:28:41 --> Total execution time: 24.5014
INFO - 2020-04-18 17:28:41 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:41 --> Email Class Initialized
INFO - 2020-04-18 17:28:41 --> Controller Class Initialized
DEBUG - 2020-04-18 17:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:42 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:42 --> Config Class Initialized
INFO - 2020-04-18 17:28:42 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:42 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:42 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:42 --> URI Class Initialized
INFO - 2020-04-18 17:28:42 --> Router Class Initialized
INFO - 2020-04-18 17:28:42 --> Output Class Initialized
INFO - 2020-04-18 17:28:42 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:42 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:42 --> Input Class Initialized
INFO - 2020-04-18 17:28:42 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:42 --> Language Class Initialized
INFO - 2020-04-18 17:28:42 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:42 --> Upload Class Initialized
INFO - 2020-04-18 17:28:42 --> Loader Class Initialized
INFO - 2020-04-18 17:28:42 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:42 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:42 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:42 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:42 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:42 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:42 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:42 --> Final output sent to browser
INFO - 2020-04-18 17:28:42 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:42 --> Total execution time: 24.4480
DEBUG - 2020-04-18 17:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:42 --> Controller Class Initialized
INFO - 2020-04-18 17:28:42 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:43 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:43 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:43 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:43 --> Upload Class Initialized
INFO - 2020-04-18 17:28:43 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:43 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:43 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:43 --> Final output sent to browser
DEBUG - 2020-04-18 17:28:43 --> Total execution time: 24.4258
INFO - 2020-04-18 17:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:43 --> Controller Class Initialized
INFO - 2020-04-18 17:28:43 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:43 --> Config Class Initialized
INFO - 2020-04-18 17:28:43 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:43 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:44 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:44 --> URI Class Initialized
INFO - 2020-04-18 17:28:44 --> Router Class Initialized
INFO - 2020-04-18 17:28:44 --> Output Class Initialized
INFO - 2020-04-18 17:28:44 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:44 --> Input Class Initialized
INFO - 2020-04-18 17:28:44 --> Language Class Initialized
INFO - 2020-04-18 17:28:44 --> Loader Class Initialized
INFO - 2020-04-18 17:28:44 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:44 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:44 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:44 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:44 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:44 --> Config Class Initialized
INFO - 2020-04-18 17:28:44 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:44 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:44 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:44 --> URI Class Initialized
INFO - 2020-04-18 17:28:44 --> Router Class Initialized
INFO - 2020-04-18 17:28:44 --> Output Class Initialized
INFO - 2020-04-18 17:28:44 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:44 --> Input Class Initialized
INFO - 2020-04-18 17:28:44 --> Language Class Initialized
INFO - 2020-04-18 17:28:44 --> Loader Class Initialized
INFO - 2020-04-18 17:28:44 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:44 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:44 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:44 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:44 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:44 --> Config Class Initialized
INFO - 2020-04-18 17:28:45 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:45 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:45 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:45 --> URI Class Initialized
INFO - 2020-04-18 17:28:45 --> Router Class Initialized
INFO - 2020-04-18 17:28:45 --> Output Class Initialized
INFO - 2020-04-18 17:28:45 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:45 --> Input Class Initialized
INFO - 2020-04-18 17:28:45 --> Language Class Initialized
INFO - 2020-04-18 17:28:45 --> Loader Class Initialized
INFO - 2020-04-18 17:28:45 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:45 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:45 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:45 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:45 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:45 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:45 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:45 --> Upload Class Initialized
INFO - 2020-04-18 17:28:45 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:45 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:45 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:45 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:45 --> Final output sent to browser
DEBUG - 2020-04-18 17:28:45 --> Total execution time: 25.5065
INFO - 2020-04-18 17:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:45 --> Controller Class Initialized
INFO - 2020-04-18 17:28:45 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:46 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:46 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:46 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:46 --> Upload Class Initialized
INFO - 2020-04-18 17:28:46 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:46 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:46 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:46 --> Final output sent to browser
DEBUG - 2020-04-18 17:28:46 --> Total execution time: 26.8257
INFO - 2020-04-18 17:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:46 --> Controller Class Initialized
INFO - 2020-04-18 17:28:46 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:47 --> Config Class Initialized
INFO - 2020-04-18 17:28:47 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:47 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:47 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:47 --> URI Class Initialized
INFO - 2020-04-18 17:28:47 --> Router Class Initialized
INFO - 2020-04-18 17:28:47 --> Output Class Initialized
INFO - 2020-04-18 17:28:47 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:47 --> Input Class Initialized
INFO - 2020-04-18 17:28:47 --> Language Class Initialized
INFO - 2020-04-18 17:28:47 --> Loader Class Initialized
INFO - 2020-04-18 17:28:47 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:47 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:47 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:47 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:47 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:47 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:47 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:47 --> Upload Class Initialized
INFO - 2020-04-18 17:28:47 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:47 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:47 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:47 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:47 --> Final output sent to browser
DEBUG - 2020-04-18 17:28:47 --> Total execution time: 27.0574
INFO - 2020-04-18 17:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:47 --> Controller Class Initialized
INFO - 2020-04-18 17:28:47 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:48 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:48 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:48 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:48 --> Upload Class Initialized
INFO - 2020-04-18 17:28:48 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:48 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:48 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:48 --> Final output sent to browser
DEBUG - 2020-04-18 17:28:48 --> Total execution time: 26.9349
INFO - 2020-04-18 17:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:48 --> Controller Class Initialized
INFO - 2020-04-18 17:28:48 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:48 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:48 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:48 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:48 --> Upload Class Initialized
INFO - 2020-04-18 17:28:48 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:48 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:48 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:48 --> Final output sent to browser
DEBUG - 2020-04-18 17:28:49 --> Total execution time: 26.7333
INFO - 2020-04-18 17:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:49 --> Controller Class Initialized
INFO - 2020-04-18 17:28:49 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:49 --> Config Class Initialized
INFO - 2020-04-18 17:28:49 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:49 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:49 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:49 --> URI Class Initialized
INFO - 2020-04-18 17:28:49 --> Router Class Initialized
INFO - 2020-04-18 17:28:49 --> Output Class Initialized
INFO - 2020-04-18 17:28:49 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:49 --> Input Class Initialized
INFO - 2020-04-18 17:28:49 --> Language Class Initialized
INFO - 2020-04-18 17:28:49 --> Loader Class Initialized
INFO - 2020-04-18 17:28:49 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:49 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:49 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:49 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:49 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:49 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:49 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:49 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:49 --> Upload Class Initialized
INFO - 2020-04-18 17:28:49 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:49 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:49 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:50 --> Final output sent to browser
INFO - 2020-04-18 17:28:50 --> Config Class Initialized
INFO - 2020-04-18 17:28:50 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:50 --> Total execution time: 27.2667
INFO - 2020-04-18 17:28:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-18 17:28:50 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:50 --> Controller Class Initialized
INFO - 2020-04-18 17:28:50 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:50 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:50 --> URI Class Initialized
INFO - 2020-04-18 17:28:50 --> Router Class Initialized
INFO - 2020-04-18 17:28:50 --> Output Class Initialized
INFO - 2020-04-18 17:28:50 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:50 --> Input Class Initialized
INFO - 2020-04-18 17:28:50 --> Language Class Initialized
INFO - 2020-04-18 17:28:50 --> Loader Class Initialized
INFO - 2020-04-18 17:28:50 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:50 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:50 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:50 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:50 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:50 --> Config Class Initialized
INFO - 2020-04-18 17:28:50 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:50 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:50 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:50 --> URI Class Initialized
INFO - 2020-04-18 17:28:50 --> Router Class Initialized
INFO - 2020-04-18 17:28:50 --> Output Class Initialized
INFO - 2020-04-18 17:28:50 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:50 --> Input Class Initialized
INFO - 2020-04-18 17:28:50 --> Language Class Initialized
INFO - 2020-04-18 17:28:50 --> Loader Class Initialized
INFO - 2020-04-18 17:28:50 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:50 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:50 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:50 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:51 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:51 --> Config Class Initialized
INFO - 2020-04-18 17:28:51 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:51 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:51 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:51 --> URI Class Initialized
INFO - 2020-04-18 17:28:51 --> Router Class Initialized
INFO - 2020-04-18 17:28:51 --> Output Class Initialized
INFO - 2020-04-18 17:28:51 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:51 --> Input Class Initialized
INFO - 2020-04-18 17:28:51 --> Language Class Initialized
INFO - 2020-04-18 17:28:51 --> Loader Class Initialized
INFO - 2020-04-18 17:28:51 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:51 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:51 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:51 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:51 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:51 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:51 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:51 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:51 --> Upload Class Initialized
INFO - 2020-04-18 17:28:51 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:51 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:51 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:51 --> Final output sent to browser
DEBUG - 2020-04-18 17:28:51 --> Total execution time: 28.0939
INFO - 2020-04-18 17:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:51 --> Controller Class Initialized
INFO - 2020-04-18 17:28:51 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:52 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:52 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:52 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:52 --> Upload Class Initialized
INFO - 2020-04-18 17:28:52 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:52 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:52 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:52 --> Final output sent to browser
DEBUG - 2020-04-18 17:28:52 --> Total execution time: 27.8186
INFO - 2020-04-18 17:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:52 --> Controller Class Initialized
INFO - 2020-04-18 17:28:52 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:52 --> Config Class Initialized
INFO - 2020-04-18 17:28:52 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:52 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:52 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:52 --> URI Class Initialized
INFO - 2020-04-18 17:28:53 --> Router Class Initialized
INFO - 2020-04-18 17:28:53 --> Output Class Initialized
INFO - 2020-04-18 17:28:53 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:53 --> Input Class Initialized
INFO - 2020-04-18 17:28:53 --> Language Class Initialized
INFO - 2020-04-18 17:28:53 --> Loader Class Initialized
INFO - 2020-04-18 17:28:53 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:53 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:53 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:53 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:53 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:53 --> Config Class Initialized
INFO - 2020-04-18 17:28:53 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:53 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:53 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:53 --> URI Class Initialized
INFO - 2020-04-18 17:28:53 --> Router Class Initialized
INFO - 2020-04-18 17:28:53 --> Output Class Initialized
INFO - 2020-04-18 17:28:53 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:53 --> Input Class Initialized
INFO - 2020-04-18 17:28:53 --> Language Class Initialized
INFO - 2020-04-18 17:28:53 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:53 --> Loader Class Initialized
INFO - 2020-04-18 17:28:53 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:53 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:53 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:53 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:53 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:53 --> Upload Class Initialized
INFO - 2020-04-18 17:28:53 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:53 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:53 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:53 --> Email Class Initialized
INFO - 2020-04-18 17:28:53 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
DEBUG - 2020-04-18 17:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:53 --> Final output sent to browser
DEBUG - 2020-04-18 17:28:53 --> Total execution time: 27.9828
INFO - 2020-04-18 17:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:53 --> Controller Class Initialized
INFO - 2020-04-18 17:28:53 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:54 --> Config Class Initialized
INFO - 2020-04-18 17:28:54 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:54 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:54 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:54 --> URI Class Initialized
INFO - 2020-04-18 17:28:54 --> Router Class Initialized
INFO - 2020-04-18 17:28:54 --> Output Class Initialized
INFO - 2020-04-18 17:28:54 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:54 --> Input Class Initialized
INFO - 2020-04-18 17:28:54 --> Language Class Initialized
INFO - 2020-04-18 17:28:54 --> Loader Class Initialized
INFO - 2020-04-18 17:28:54 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:54 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:54 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:54 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:54 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:54 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:54 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:54 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:54 --> Upload Class Initialized
INFO - 2020-04-18 17:28:54 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:54 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:55 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:55 --> Final output sent to browser
DEBUG - 2020-04-18 17:28:55 --> Total execution time: 28.5927
INFO - 2020-04-18 17:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:55 --> Controller Class Initialized
INFO - 2020-04-18 17:28:55 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:56 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:56 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:56 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:56 --> Upload Class Initialized
INFO - 2020-04-18 17:28:56 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:56 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:56 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:56 --> Final output sent to browser
DEBUG - 2020-04-18 17:28:56 --> Total execution time: 28.9642
INFO - 2020-04-18 17:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:56 --> Controller Class Initialized
INFO - 2020-04-18 17:28:56 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:56 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:56 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:56 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:56 --> Upload Class Initialized
INFO - 2020-04-18 17:28:56 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:56 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:56 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:56 --> Final output sent to browser
DEBUG - 2020-04-18 17:28:56 --> Total execution time: 29.3003
INFO - 2020-04-18 17:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:56 --> Controller Class Initialized
INFO - 2020-04-18 17:28:57 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:57 --> Config Class Initialized
INFO - 2020-04-18 17:28:57 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:57 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:57 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:57 --> URI Class Initialized
INFO - 2020-04-18 17:28:57 --> Router Class Initialized
INFO - 2020-04-18 17:28:57 --> Output Class Initialized
INFO - 2020-04-18 17:28:57 --> Security Class Initialized
DEBUG - 2020-04-18 17:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:57 --> Input Class Initialized
INFO - 2020-04-18 17:28:57 --> Language Class Initialized
INFO - 2020-04-18 17:28:57 --> Loader Class Initialized
INFO - 2020-04-18 17:28:57 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:57 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:57 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:57 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:57 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:57 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:57 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:57 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:57 --> Upload Class Initialized
INFO - 2020-04-18 17:28:57 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:57 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:57 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:57 --> Final output sent to browser
DEBUG - 2020-04-18 17:28:57 --> Total execution time: 29.2046
INFO - 2020-04-18 17:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:57 --> Controller Class Initialized
INFO - 2020-04-18 17:28:57 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:58 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:58 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:58 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:58 --> Upload Class Initialized
INFO - 2020-04-18 17:28:58 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:58 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:58 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:58 --> Final output sent to browser
DEBUG - 2020-04-18 17:28:58 --> Total execution time: 29.3222
INFO - 2020-04-18 17:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:58 --> Controller Class Initialized
INFO - 2020-04-18 17:28:58 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:58 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:58 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:58 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:58 --> Upload Class Initialized
INFO - 2020-04-18 17:28:58 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:28:58 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:28:58 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:28:58 --> Final output sent to browser
DEBUG - 2020-04-18 17:28:58 --> Total execution time: 29.2986
INFO - 2020-04-18 17:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:28:58 --> Controller Class Initialized
INFO - 2020-04-18 17:28:58 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:28:59 --> Config Class Initialized
INFO - 2020-04-18 17:28:59 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:59 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:59 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:59 --> URI Class Initialized
INFO - 2020-04-18 17:28:59 --> Router Class Initialized
INFO - 2020-04-18 17:28:59 --> Output Class Initialized
INFO - 2020-04-18 17:28:59 --> Security Class Initialized
INFO - 2020-04-18 17:28:59 --> Config Class Initialized
INFO - 2020-04-18 17:28:59 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:59 --> Input Class Initialized
DEBUG - 2020-04-18 17:28:59 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:28:59 --> Utf8 Class Initialized
INFO - 2020-04-18 17:28:59 --> Language Class Initialized
INFO - 2020-04-18 17:28:59 --> URI Class Initialized
INFO - 2020-04-18 17:28:59 --> Loader Class Initialized
INFO - 2020-04-18 17:28:59 --> Router Class Initialized
INFO - 2020-04-18 17:28:59 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:59 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:59 --> Output Class Initialized
INFO - 2020-04-18 17:28:59 --> Security Class Initialized
INFO - 2020-04-18 17:28:59 --> Helper loaded: form_helper
DEBUG - 2020-04-18 17:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:28:59 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:59 --> Input Class Initialized
INFO - 2020-04-18 17:28:59 --> Email Class Initialized
INFO - 2020-04-18 17:28:59 --> Language Class Initialized
DEBUG - 2020-04-18 17:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:59 --> Loader Class Initialized
INFO - 2020-04-18 17:28:59 --> Helper loaded: url_helper
INFO - 2020-04-18 17:28:59 --> Helper loaded: file_helper
INFO - 2020-04-18 17:28:59 --> Helper loaded: form_helper
INFO - 2020-04-18 17:28:59 --> Database Driver Class Initialized
INFO - 2020-04-18 17:28:59 --> Email Class Initialized
DEBUG - 2020-04-18 17:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:28:59 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:28:59 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:28:59 --> Form Validation Class Initialized
INFO - 2020-04-18 17:28:59 --> Upload Class Initialized
INFO - 2020-04-18 17:29:00 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:00 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:00 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:00 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:00 --> Total execution time: 29.5300
INFO - 2020-04-18 17:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:00 --> Controller Class Initialized
INFO - 2020-04-18 17:29:00 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:00 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:00 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:00 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:00 --> Upload Class Initialized
INFO - 2020-04-18 17:29:00 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:00 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:00 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:00 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:00 --> Total execution time: 29.7159
INFO - 2020-04-18 17:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:00 --> Controller Class Initialized
INFO - 2020-04-18 17:29:00 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:00 --> Config Class Initialized
INFO - 2020-04-18 17:29:00 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:29:00 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:29:00 --> Utf8 Class Initialized
INFO - 2020-04-18 17:29:00 --> URI Class Initialized
INFO - 2020-04-18 17:29:01 --> Router Class Initialized
INFO - 2020-04-18 17:29:01 --> Output Class Initialized
INFO - 2020-04-18 17:29:01 --> Security Class Initialized
DEBUG - 2020-04-18 17:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:29:01 --> Input Class Initialized
INFO - 2020-04-18 17:29:01 --> Language Class Initialized
INFO - 2020-04-18 17:29:01 --> Loader Class Initialized
INFO - 2020-04-18 17:29:01 --> Helper loaded: url_helper
INFO - 2020-04-18 17:29:01 --> Helper loaded: file_helper
INFO - 2020-04-18 17:29:01 --> Helper loaded: form_helper
INFO - 2020-04-18 17:29:01 --> Database Driver Class Initialized
INFO - 2020-04-18 17:29:01 --> Email Class Initialized
DEBUG - 2020-04-18 17:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:29:01 --> Config Class Initialized
INFO - 2020-04-18 17:29:01 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:29:01 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:29:01 --> Utf8 Class Initialized
INFO - 2020-04-18 17:29:01 --> URI Class Initialized
INFO - 2020-04-18 17:29:01 --> Router Class Initialized
INFO - 2020-04-18 17:29:01 --> Output Class Initialized
INFO - 2020-04-18 17:29:01 --> Security Class Initialized
DEBUG - 2020-04-18 17:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:29:01 --> Input Class Initialized
INFO - 2020-04-18 17:29:01 --> Language Class Initialized
INFO - 2020-04-18 17:29:01 --> Loader Class Initialized
INFO - 2020-04-18 17:29:01 --> Helper loaded: url_helper
INFO - 2020-04-18 17:29:01 --> Helper loaded: file_helper
INFO - 2020-04-18 17:29:01 --> Helper loaded: form_helper
INFO - 2020-04-18 17:29:01 --> Database Driver Class Initialized
INFO - 2020-04-18 17:29:02 --> Email Class Initialized
DEBUG - 2020-04-18 17:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:29:02 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:02 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:02 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:02 --> Upload Class Initialized
INFO - 2020-04-18 17:29:02 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:02 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:02 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:02 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:03 --> Total execution time: 31.4996
INFO - 2020-04-18 17:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:03 --> Controller Class Initialized
INFO - 2020-04-18 17:29:03 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:03 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:03 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:03 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:03 --> Upload Class Initialized
INFO - 2020-04-18 17:29:03 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:03 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:03 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:03 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:03 --> Total execution time: 30.8869
INFO - 2020-04-18 17:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:03 --> Controller Class Initialized
INFO - 2020-04-18 17:29:03 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:04 --> Config Class Initialized
INFO - 2020-04-18 17:29:04 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:29:04 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:29:04 --> Utf8 Class Initialized
INFO - 2020-04-18 17:29:04 --> URI Class Initialized
INFO - 2020-04-18 17:29:04 --> Router Class Initialized
INFO - 2020-04-18 17:29:04 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:04 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:04 --> Output Class Initialized
INFO - 2020-04-18 17:29:04 --> Security Class Initialized
INFO - 2020-04-18 17:29:04 --> Form Validation Class Initialized
DEBUG - 2020-04-18 17:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:29:04 --> Upload Class Initialized
INFO - 2020-04-18 17:29:04 --> Input Class Initialized
INFO - 2020-04-18 17:29:04 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:04 --> Language Class Initialized
INFO - 2020-04-18 17:29:04 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:04 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:04 --> Loader Class Initialized
INFO - 2020-04-18 17:29:04 --> Final output sent to browser
INFO - 2020-04-18 17:29:04 --> Helper loaded: url_helper
DEBUG - 2020-04-18 17:29:04 --> Total execution time: 31.0155
INFO - 2020-04-18 17:29:04 --> Helper loaded: file_helper
INFO - 2020-04-18 17:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:04 --> Helper loaded: form_helper
INFO - 2020-04-18 17:29:04 --> Controller Class Initialized
INFO - 2020-04-18 17:29:04 --> Database Driver Class Initialized
INFO - 2020-04-18 17:29:04 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:04 --> Email Class Initialized
DEBUG - 2020-04-18 17:29:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:29:04 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:04 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:04 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:04 --> Upload Class Initialized
INFO - 2020-04-18 17:29:04 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:05 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:05 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:05 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:05 --> Total execution time: 31.0843
INFO - 2020-04-18 17:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:05 --> Controller Class Initialized
INFO - 2020-04-18 17:29:05 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:05 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:05 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:05 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:05 --> Upload Class Initialized
INFO - 2020-04-18 17:29:05 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:05 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:05 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:05 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:05 --> Total execution time: 31.2218
INFO - 2020-04-18 17:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:05 --> Controller Class Initialized
INFO - 2020-04-18 17:29:05 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:06 --> Config Class Initialized
INFO - 2020-04-18 17:29:06 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:29:06 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:29:06 --> Utf8 Class Initialized
INFO - 2020-04-18 17:29:06 --> URI Class Initialized
INFO - 2020-04-18 17:29:06 --> Router Class Initialized
INFO - 2020-04-18 17:29:06 --> Output Class Initialized
INFO - 2020-04-18 17:29:06 --> Security Class Initialized
DEBUG - 2020-04-18 17:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:29:06 --> Input Class Initialized
INFO - 2020-04-18 17:29:06 --> Language Class Initialized
INFO - 2020-04-18 17:29:06 --> Loader Class Initialized
INFO - 2020-04-18 17:29:06 --> Helper loaded: url_helper
INFO - 2020-04-18 17:29:06 --> Helper loaded: file_helper
INFO - 2020-04-18 17:29:06 --> Helper loaded: form_helper
INFO - 2020-04-18 17:29:06 --> Database Driver Class Initialized
INFO - 2020-04-18 17:29:06 --> Email Class Initialized
DEBUG - 2020-04-18 17:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:29:06 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:06 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:06 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:06 --> Upload Class Initialized
INFO - 2020-04-18 17:29:06 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:06 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:06 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:06 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:06 --> Total execution time: 30.8213
INFO - 2020-04-18 17:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:07 --> Controller Class Initialized
INFO - 2020-04-18 17:29:07 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:07 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:07 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:07 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:07 --> Upload Class Initialized
INFO - 2020-04-18 17:29:07 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:07 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:07 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:07 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:07 --> Total execution time: 30.8508
INFO - 2020-04-18 17:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:07 --> Controller Class Initialized
INFO - 2020-04-18 17:29:07 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:07 --> Config Class Initialized
INFO - 2020-04-18 17:29:07 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:29:07 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:29:07 --> Utf8 Class Initialized
INFO - 2020-04-18 17:29:07 --> URI Class Initialized
INFO - 2020-04-18 17:29:07 --> Router Class Initialized
INFO - 2020-04-18 17:29:07 --> Output Class Initialized
INFO - 2020-04-18 17:29:07 --> Security Class Initialized
DEBUG - 2020-04-18 17:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:29:07 --> Input Class Initialized
INFO - 2020-04-18 17:29:07 --> Language Class Initialized
INFO - 2020-04-18 17:29:07 --> Loader Class Initialized
INFO - 2020-04-18 17:29:07 --> Helper loaded: url_helper
INFO - 2020-04-18 17:29:07 --> Helper loaded: file_helper
INFO - 2020-04-18 17:29:08 --> Helper loaded: form_helper
INFO - 2020-04-18 17:29:08 --> Database Driver Class Initialized
INFO - 2020-04-18 17:29:08 --> Email Class Initialized
DEBUG - 2020-04-18 17:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:29:08 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:08 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:08 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:08 --> Upload Class Initialized
INFO - 2020-04-18 17:29:08 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:08 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:08 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:08 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:08 --> Total execution time: 31.4073
INFO - 2020-04-18 17:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:08 --> Controller Class Initialized
INFO - 2020-04-18 17:29:08 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:09 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:09 --> Config Class Initialized
INFO - 2020-04-18 17:29:09 --> Hooks Class Initialized
INFO - 2020-04-18 17:29:09 --> Model "Appsettings_model" initialized
DEBUG - 2020-04-18 17:29:09 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:29:09 --> Utf8 Class Initialized
INFO - 2020-04-18 17:29:09 --> URI Class Initialized
INFO - 2020-04-18 17:29:09 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:09 --> Router Class Initialized
INFO - 2020-04-18 17:29:09 --> Upload Class Initialized
INFO - 2020-04-18 17:29:09 --> Output Class Initialized
INFO - 2020-04-18 17:29:09 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:09 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:09 --> Security Class Initialized
INFO - 2020-04-18 17:29:09 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
DEBUG - 2020-04-18 17:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:29:09 --> Input Class Initialized
INFO - 2020-04-18 17:29:09 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:09 --> Total execution time: 31.7865
INFO - 2020-04-18 17:29:09 --> Language Class Initialized
INFO - 2020-04-18 17:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:09 --> Loader Class Initialized
INFO - 2020-04-18 17:29:09 --> Controller Class Initialized
INFO - 2020-04-18 17:29:09 --> Helper loaded: url_helper
INFO - 2020-04-18 17:29:09 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:09 --> Helper loaded: file_helper
INFO - 2020-04-18 17:29:09 --> Helper loaded: form_helper
INFO - 2020-04-18 17:29:09 --> Database Driver Class Initialized
INFO - 2020-04-18 17:29:09 --> Email Class Initialized
DEBUG - 2020-04-18 17:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:29:10 --> Config Class Initialized
INFO - 2020-04-18 17:29:10 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:29:10 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:29:10 --> Utf8 Class Initialized
INFO - 2020-04-18 17:29:10 --> URI Class Initialized
INFO - 2020-04-18 17:29:10 --> Router Class Initialized
INFO - 2020-04-18 17:29:10 --> Output Class Initialized
INFO - 2020-04-18 17:29:10 --> Security Class Initialized
DEBUG - 2020-04-18 17:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:29:10 --> Input Class Initialized
INFO - 2020-04-18 17:29:10 --> Language Class Initialized
INFO - 2020-04-18 17:29:10 --> Loader Class Initialized
INFO - 2020-04-18 17:29:10 --> Helper loaded: url_helper
INFO - 2020-04-18 17:29:10 --> Helper loaded: file_helper
INFO - 2020-04-18 17:29:10 --> Helper loaded: form_helper
INFO - 2020-04-18 17:29:10 --> Database Driver Class Initialized
INFO - 2020-04-18 17:29:10 --> Email Class Initialized
DEBUG - 2020-04-18 17:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:29:10 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:10 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:10 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:10 --> Upload Class Initialized
INFO - 2020-04-18 17:29:10 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:10 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:10 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:10 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:10 --> Total execution time: 32.6005
INFO - 2020-04-18 17:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:10 --> Controller Class Initialized
INFO - 2020-04-18 17:29:11 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:11 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:11 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:11 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:11 --> Upload Class Initialized
INFO - 2020-04-18 17:29:11 --> Config Class Initialized
INFO - 2020-04-18 17:29:11 --> Hooks Class Initialized
INFO - 2020-04-18 17:29:11 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
DEBUG - 2020-04-18 17:29:11 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:29:11 --> Utf8 Class Initialized
INFO - 2020-04-18 17:29:11 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:11 --> URI Class Initialized
INFO - 2020-04-18 17:29:11 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:11 --> Final output sent to browser
INFO - 2020-04-18 17:29:11 --> Router Class Initialized
DEBUG - 2020-04-18 17:29:11 --> Total execution time: 33.0220
INFO - 2020-04-18 17:29:11 --> Output Class Initialized
INFO - 2020-04-18 17:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:11 --> Security Class Initialized
INFO - 2020-04-18 17:29:11 --> Controller Class Initialized
DEBUG - 2020-04-18 17:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:29:11 --> Input Class Initialized
INFO - 2020-04-18 17:29:11 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:11 --> Language Class Initialized
INFO - 2020-04-18 17:29:11 --> Loader Class Initialized
INFO - 2020-04-18 17:29:11 --> Helper loaded: url_helper
INFO - 2020-04-18 17:29:11 --> Helper loaded: file_helper
INFO - 2020-04-18 17:29:11 --> Helper loaded: form_helper
INFO - 2020-04-18 17:29:12 --> Database Driver Class Initialized
INFO - 2020-04-18 17:29:12 --> Email Class Initialized
DEBUG - 2020-04-18 17:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:29:12 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:12 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:12 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:12 --> Upload Class Initialized
INFO - 2020-04-18 17:29:12 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:12 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:12 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:12 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:12 --> Total execution time: 33.0498
INFO - 2020-04-18 17:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:12 --> Controller Class Initialized
INFO - 2020-04-18 17:29:12 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:13 --> Config Class Initialized
INFO - 2020-04-18 17:29:13 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:29:13 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:29:13 --> Config Class Initialized
INFO - 2020-04-18 17:29:13 --> Hooks Class Initialized
INFO - 2020-04-18 17:29:13 --> Utf8 Class Initialized
INFO - 2020-04-18 17:29:13 --> URI Class Initialized
DEBUG - 2020-04-18 17:29:13 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:29:13 --> Utf8 Class Initialized
INFO - 2020-04-18 17:29:13 --> Router Class Initialized
INFO - 2020-04-18 17:29:13 --> URI Class Initialized
INFO - 2020-04-18 17:29:13 --> Output Class Initialized
INFO - 2020-04-18 17:29:13 --> Security Class Initialized
INFO - 2020-04-18 17:29:13 --> Router Class Initialized
INFO - 2020-04-18 17:29:13 --> Output Class Initialized
DEBUG - 2020-04-18 17:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:29:13 --> Input Class Initialized
INFO - 2020-04-18 17:29:13 --> Security Class Initialized
INFO - 2020-04-18 17:29:13 --> Language Class Initialized
DEBUG - 2020-04-18 17:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:29:13 --> Input Class Initialized
INFO - 2020-04-18 17:29:13 --> Loader Class Initialized
INFO - 2020-04-18 17:29:13 --> Language Class Initialized
INFO - 2020-04-18 17:29:13 --> Helper loaded: url_helper
INFO - 2020-04-18 17:29:13 --> Helper loaded: file_helper
INFO - 2020-04-18 17:29:13 --> Loader Class Initialized
INFO - 2020-04-18 17:29:13 --> Helper loaded: form_helper
INFO - 2020-04-18 17:29:13 --> Helper loaded: url_helper
INFO - 2020-04-18 17:29:13 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:13 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:13 --> Database Driver Class Initialized
INFO - 2020-04-18 17:29:13 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:13 --> Upload Class Initialized
INFO - 2020-04-18 17:29:13 --> Email Class Initialized
DEBUG - 2020-04-18 17:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:29:13 --> Helper loaded: file_helper
INFO - 2020-04-18 17:29:13 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:13 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:13 --> Helper loaded: form_helper
INFO - 2020-04-18 17:29:13 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:13 --> Database Driver Class Initialized
INFO - 2020-04-18 17:29:13 --> Final output sent to browser
INFO - 2020-04-18 17:29:13 --> Email Class Initialized
DEBUG - 2020-04-18 17:29:13 --> Total execution time: 33.7440
DEBUG - 2020-04-18 17:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:13 --> Controller Class Initialized
INFO - 2020-04-18 17:29:13 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:14 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:14 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:14 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:14 --> Upload Class Initialized
INFO - 2020-04-18 17:29:14 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:14 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:14 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:14 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:14 --> Total execution time: 34.3308
INFO - 2020-04-18 17:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:14 --> Controller Class Initialized
INFO - 2020-04-18 17:29:14 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:14 --> Config Class Initialized
INFO - 2020-04-18 17:29:14 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:29:14 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:29:14 --> Utf8 Class Initialized
INFO - 2020-04-18 17:29:14 --> URI Class Initialized
INFO - 2020-04-18 17:29:14 --> Router Class Initialized
INFO - 2020-04-18 17:29:14 --> Output Class Initialized
INFO - 2020-04-18 17:29:14 --> Security Class Initialized
DEBUG - 2020-04-18 17:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:29:14 --> Config Class Initialized
INFO - 2020-04-18 17:29:14 --> Hooks Class Initialized
INFO - 2020-04-18 17:29:14 --> Input Class Initialized
INFO - 2020-04-18 17:29:14 --> Language Class Initialized
DEBUG - 2020-04-18 17:29:14 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:29:14 --> Utf8 Class Initialized
INFO - 2020-04-18 17:29:14 --> Loader Class Initialized
INFO - 2020-04-18 17:29:14 --> URI Class Initialized
INFO - 2020-04-18 17:29:14 --> Helper loaded: url_helper
INFO - 2020-04-18 17:29:14 --> Helper loaded: file_helper
INFO - 2020-04-18 17:29:14 --> Router Class Initialized
INFO - 2020-04-18 17:29:14 --> Helper loaded: form_helper
INFO - 2020-04-18 17:29:14 --> Output Class Initialized
INFO - 2020-04-18 17:29:14 --> Security Class Initialized
INFO - 2020-04-18 17:29:14 --> Database Driver Class Initialized
DEBUG - 2020-04-18 17:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:29:15 --> Email Class Initialized
INFO - 2020-04-18 17:29:15 --> Input Class Initialized
DEBUG - 2020-04-18 17:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:29:15 --> Language Class Initialized
INFO - 2020-04-18 17:29:15 --> Loader Class Initialized
INFO - 2020-04-18 17:29:15 --> Helper loaded: url_helper
INFO - 2020-04-18 17:29:15 --> Helper loaded: file_helper
INFO - 2020-04-18 17:29:15 --> Helper loaded: form_helper
INFO - 2020-04-18 17:29:15 --> Database Driver Class Initialized
INFO - 2020-04-18 17:29:15 --> Email Class Initialized
DEBUG - 2020-04-18 17:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:29:15 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:15 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:15 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:15 --> Upload Class Initialized
INFO - 2020-04-18 17:29:15 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:15 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:15 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:15 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:15 --> Total execution time: 34.5199
INFO - 2020-04-18 17:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:15 --> Controller Class Initialized
INFO - 2020-04-18 17:29:15 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:15 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:16 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:16 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:16 --> Upload Class Initialized
INFO - 2020-04-18 17:29:16 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:16 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:16 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:16 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:16 --> Total execution time: 34.7283
INFO - 2020-04-18 17:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:16 --> Controller Class Initialized
INFO - 2020-04-18 17:29:16 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:16 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:16 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:16 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:16 --> Upload Class Initialized
INFO - 2020-04-18 17:29:16 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:16 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:16 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:16 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:16 --> Total execution time: 34.6065
INFO - 2020-04-18 17:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:16 --> Controller Class Initialized
INFO - 2020-04-18 17:29:16 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:16 --> Config Class Initialized
INFO - 2020-04-18 17:29:16 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:29:17 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:29:17 --> Utf8 Class Initialized
INFO - 2020-04-18 17:29:17 --> URI Class Initialized
INFO - 2020-04-18 17:29:17 --> Router Class Initialized
INFO - 2020-04-18 17:29:17 --> Output Class Initialized
INFO - 2020-04-18 17:29:17 --> Security Class Initialized
DEBUG - 2020-04-18 17:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:29:17 --> Input Class Initialized
INFO - 2020-04-18 17:29:17 --> Language Class Initialized
INFO - 2020-04-18 17:29:17 --> Loader Class Initialized
INFO - 2020-04-18 17:29:17 --> Helper loaded: url_helper
INFO - 2020-04-18 17:29:17 --> Helper loaded: file_helper
INFO - 2020-04-18 17:29:17 --> Helper loaded: form_helper
INFO - 2020-04-18 17:29:17 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:17 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:17 --> Database Driver Class Initialized
INFO - 2020-04-18 17:29:17 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:17 --> Email Class Initialized
INFO - 2020-04-18 17:29:17 --> Upload Class Initialized
DEBUG - 2020-04-18 17:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:29:17 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:17 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:17 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:17 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:17 --> Total execution time: 33.5724
INFO - 2020-04-18 17:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:17 --> Controller Class Initialized
INFO - 2020-04-18 17:29:17 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:18 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:18 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:18 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:18 --> Upload Class Initialized
INFO - 2020-04-18 17:29:18 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:18 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:18 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:18 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:18 --> Total execution time: 33.6957
INFO - 2020-04-18 17:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:18 --> Controller Class Initialized
INFO - 2020-04-18 17:29:18 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:18 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:18 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:18 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:18 --> Upload Class Initialized
INFO - 2020-04-18 17:29:18 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:18 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:18 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:18 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:18 --> Total execution time: 33.8281
INFO - 2020-04-18 17:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:18 --> Controller Class Initialized
INFO - 2020-04-18 17:29:18 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:19 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:19 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:20 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:20 --> Upload Class Initialized
INFO - 2020-04-18 17:29:20 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:20 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:20 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:20 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:20 --> Total execution time: 33.1817
INFO - 2020-04-18 17:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:20 --> Controller Class Initialized
INFO - 2020-04-18 17:29:20 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:20 --> Config Class Initialized
INFO - 2020-04-18 17:29:20 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:29:20 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:29:20 --> Utf8 Class Initialized
INFO - 2020-04-18 17:29:20 --> URI Class Initialized
INFO - 2020-04-18 17:29:20 --> Router Class Initialized
INFO - 2020-04-18 17:29:20 --> Output Class Initialized
INFO - 2020-04-18 17:29:20 --> Security Class Initialized
DEBUG - 2020-04-18 17:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:29:20 --> Input Class Initialized
INFO - 2020-04-18 17:29:20 --> Language Class Initialized
INFO - 2020-04-18 17:29:20 --> Loader Class Initialized
INFO - 2020-04-18 17:29:20 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:20 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:20 --> Helper loaded: url_helper
INFO - 2020-04-18 17:29:20 --> Helper loaded: file_helper
INFO - 2020-04-18 17:29:20 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:20 --> Upload Class Initialized
INFO - 2020-04-18 17:29:20 --> Helper loaded: form_helper
INFO - 2020-04-18 17:29:20 --> Database Driver Class Initialized
INFO - 2020-04-18 17:29:20 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:20 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:20 --> Email Class Initialized
INFO - 2020-04-18 17:29:20 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
DEBUG - 2020-04-18 17:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:29:20 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:20 --> Total execution time: 31.6331
INFO - 2020-04-18 17:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:20 --> Controller Class Initialized
INFO - 2020-04-18 17:29:20 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:21 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:21 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:21 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:21 --> Upload Class Initialized
INFO - 2020-04-18 17:29:21 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:21 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:21 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:21 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:21 --> Total execution time: 31.4086
INFO - 2020-04-18 17:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:21 --> Controller Class Initialized
INFO - 2020-04-18 17:29:21 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:22 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:22 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:22 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:22 --> Upload Class Initialized
INFO - 2020-04-18 17:29:22 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:22 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:22 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:22 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:22 --> Total execution time: 31.4886
INFO - 2020-04-18 17:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:22 --> Controller Class Initialized
INFO - 2020-04-18 17:29:22 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:22 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:22 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:22 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:22 --> Upload Class Initialized
INFO - 2020-04-18 17:29:22 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:22 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:22 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:22 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:22 --> Total execution time: 31.5192
INFO - 2020-04-18 17:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:22 --> Controller Class Initialized
INFO - 2020-04-18 17:29:22 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:23 --> Config Class Initialized
INFO - 2020-04-18 17:29:23 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:29:23 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:29:23 --> Utf8 Class Initialized
INFO - 2020-04-18 17:29:23 --> URI Class Initialized
INFO - 2020-04-18 17:29:23 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:23 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:23 --> Router Class Initialized
INFO - 2020-04-18 17:29:23 --> Config Class Initialized
INFO - 2020-04-18 17:29:23 --> Hooks Class Initialized
INFO - 2020-04-18 17:29:23 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:23 --> Upload Class Initialized
DEBUG - 2020-04-18 17:29:23 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:29:23 --> Utf8 Class Initialized
INFO - 2020-04-18 17:29:23 --> URI Class Initialized
INFO - 2020-04-18 17:29:23 --> Router Class Initialized
INFO - 2020-04-18 17:29:23 --> Output Class Initialized
INFO - 2020-04-18 17:29:23 --> Security Class Initialized
DEBUG - 2020-04-18 17:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:29:23 --> Input Class Initialized
INFO - 2020-04-18 17:29:23 --> Language Class Initialized
INFO - 2020-04-18 17:29:23 --> Loader Class Initialized
INFO - 2020-04-18 17:29:23 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:23 --> Helper loaded: url_helper
INFO - 2020-04-18 17:29:23 --> Output Class Initialized
INFO - 2020-04-18 17:29:23 --> Helper loaded: file_helper
INFO - 2020-04-18 17:29:23 --> Security Class Initialized
INFO - 2020-04-18 17:29:23 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:23 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
DEBUG - 2020-04-18 17:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:29:23 --> Helper loaded: form_helper
INFO - 2020-04-18 17:29:23 --> Input Class Initialized
INFO - 2020-04-18 17:29:23 --> Final output sent to browser
INFO - 2020-04-18 17:29:23 --> Database Driver Class Initialized
DEBUG - 2020-04-18 17:29:23 --> Total execution time: 30.8095
INFO - 2020-04-18 17:29:23 --> Language Class Initialized
INFO - 2020-04-18 17:29:23 --> Email Class Initialized
INFO - 2020-04-18 17:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:23 --> Loader Class Initialized
DEBUG - 2020-04-18 17:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:29:23 --> Controller Class Initialized
INFO - 2020-04-18 17:29:23 --> Helper loaded: url_helper
INFO - 2020-04-18 17:29:23 --> Helper loaded: file_helper
INFO - 2020-04-18 17:29:23 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:23 --> Helper loaded: form_helper
INFO - 2020-04-18 17:29:23 --> Database Driver Class Initialized
INFO - 2020-04-18 17:29:23 --> Email Class Initialized
DEBUG - 2020-04-18 17:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:29:24 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:24 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:24 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:24 --> Upload Class Initialized
INFO - 2020-04-18 17:29:24 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:24 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:24 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:24 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:24 --> Total execution time: 31.0144
INFO - 2020-04-18 17:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:24 --> Controller Class Initialized
INFO - 2020-04-18 17:29:24 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:24 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:24 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:24 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:24 --> Upload Class Initialized
INFO - 2020-04-18 17:29:25 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:25 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:25 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:25 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:25 --> Total execution time: 30.6350
INFO - 2020-04-18 17:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:25 --> Controller Class Initialized
INFO - 2020-04-18 17:29:25 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:25 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:25 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:25 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:25 --> Upload Class Initialized
INFO - 2020-04-18 17:29:25 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:25 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:25 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:25 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:25 --> Total execution time: 28.7461
INFO - 2020-04-18 17:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:25 --> Controller Class Initialized
INFO - 2020-04-18 17:29:25 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:26 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:26 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:26 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:26 --> Upload Class Initialized
INFO - 2020-04-18 17:29:26 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:26 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:26 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:26 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:26 --> Total execution time: 27.3644
INFO - 2020-04-18 17:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:26 --> Controller Class Initialized
INFO - 2020-04-18 17:29:26 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:26 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:26 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:26 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:27 --> Upload Class Initialized
INFO - 2020-04-18 17:29:27 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:27 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:27 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:27 --> Final output sent to browser
INFO - 2020-04-18 17:29:27 --> Config Class Initialized
INFO - 2020-04-18 17:29:27 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:29:27 --> Total execution time: 27.8974
INFO - 2020-04-18 17:29:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-18 17:29:27 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:29:27 --> Utf8 Class Initialized
INFO - 2020-04-18 17:29:27 --> Controller Class Initialized
INFO - 2020-04-18 17:29:27 --> URI Class Initialized
INFO - 2020-04-18 17:29:27 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:27 --> Router Class Initialized
INFO - 2020-04-18 17:29:27 --> Output Class Initialized
INFO - 2020-04-18 17:29:27 --> Security Class Initialized
DEBUG - 2020-04-18 17:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:29:27 --> Input Class Initialized
INFO - 2020-04-18 17:29:27 --> Language Class Initialized
INFO - 2020-04-18 17:29:27 --> Loader Class Initialized
INFO - 2020-04-18 17:29:27 --> Helper loaded: url_helper
INFO - 2020-04-18 17:29:27 --> Helper loaded: file_helper
INFO - 2020-04-18 17:29:27 --> Helper loaded: form_helper
INFO - 2020-04-18 17:29:27 --> Database Driver Class Initialized
INFO - 2020-04-18 17:29:27 --> Email Class Initialized
DEBUG - 2020-04-18 17:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:29:27 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:27 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:27 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:27 --> Upload Class Initialized
INFO - 2020-04-18 17:29:27 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:27 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:27 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:27 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:27 --> Total execution time: 26.9249
INFO - 2020-04-18 17:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:27 --> Controller Class Initialized
INFO - 2020-04-18 17:29:27 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:28 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:28 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:28 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:28 --> Upload Class Initialized
INFO - 2020-04-18 17:29:28 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:28 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:28 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:28 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:28 --> Total execution time: 26.7720
INFO - 2020-04-18 17:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:28 --> Controller Class Initialized
INFO - 2020-04-18 17:29:28 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:29 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:29 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:29 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:29 --> Upload Class Initialized
INFO - 2020-04-18 17:29:29 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:29 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:29 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:29 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:29 --> Total execution time: 25.0659
INFO - 2020-04-18 17:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:29 --> Controller Class Initialized
INFO - 2020-04-18 17:29:29 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:29 --> Config Class Initialized
INFO - 2020-04-18 17:29:29 --> Hooks Class Initialized
INFO - 2020-04-18 17:29:29 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:29 --> Model "Appsettings_model" initialized
DEBUG - 2020-04-18 17:29:29 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:29:29 --> Utf8 Class Initialized
INFO - 2020-04-18 17:29:29 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:29 --> URI Class Initialized
INFO - 2020-04-18 17:29:29 --> Upload Class Initialized
INFO - 2020-04-18 17:29:29 --> Router Class Initialized
INFO - 2020-04-18 17:29:29 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:29 --> Output Class Initialized
INFO - 2020-04-18 17:29:29 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:29 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:29 --> Security Class Initialized
INFO - 2020-04-18 17:29:29 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:29:29 --> Input Class Initialized
DEBUG - 2020-04-18 17:29:29 --> Total execution time: 23.7155
INFO - 2020-04-18 17:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:29 --> Language Class Initialized
INFO - 2020-04-18 17:29:29 --> Controller Class Initialized
INFO - 2020-04-18 17:29:29 --> Loader Class Initialized
INFO - 2020-04-18 17:29:29 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:29 --> Helper loaded: url_helper
INFO - 2020-04-18 17:29:29 --> Helper loaded: file_helper
INFO - 2020-04-18 17:29:29 --> Helper loaded: form_helper
INFO - 2020-04-18 17:29:30 --> Database Driver Class Initialized
INFO - 2020-04-18 17:29:30 --> Email Class Initialized
DEBUG - 2020-04-18 17:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:29:30 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:30 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:30 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:30 --> Upload Class Initialized
INFO - 2020-04-18 17:29:30 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:30 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:30 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:31 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:31 --> Total execution time: 23.3505
INFO - 2020-04-18 17:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:31 --> Controller Class Initialized
INFO - 2020-04-18 17:29:31 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:32 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:32 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:32 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:32 --> Upload Class Initialized
INFO - 2020-04-18 17:29:32 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:32 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:32 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:32 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:32 --> Total execution time: 23.2466
INFO - 2020-04-18 17:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:32 --> Controller Class Initialized
INFO - 2020-04-18 17:29:32 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:33 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:33 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:33 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:33 --> Upload Class Initialized
INFO - 2020-04-18 17:29:33 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:33 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:33 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:33 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:33 --> Total execution time: 23.3520
INFO - 2020-04-18 17:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:33 --> Controller Class Initialized
INFO - 2020-04-18 17:29:33 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:33 --> Config Class Initialized
INFO - 2020-04-18 17:29:33 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:29:34 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:29:34 --> Config Class Initialized
INFO - 2020-04-18 17:29:34 --> Hooks Class Initialized
INFO - 2020-04-18 17:29:34 --> Utf8 Class Initialized
DEBUG - 2020-04-18 17:29:34 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:29:34 --> URI Class Initialized
INFO - 2020-04-18 17:29:34 --> Utf8 Class Initialized
INFO - 2020-04-18 17:29:34 --> Router Class Initialized
INFO - 2020-04-18 17:29:34 --> URI Class Initialized
INFO - 2020-04-18 17:29:34 --> Output Class Initialized
INFO - 2020-04-18 17:29:34 --> Security Class Initialized
INFO - 2020-04-18 17:29:34 --> Router Class Initialized
DEBUG - 2020-04-18 17:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:29:34 --> Output Class Initialized
INFO - 2020-04-18 17:29:34 --> Input Class Initialized
INFO - 2020-04-18 17:29:34 --> Security Class Initialized
INFO - 2020-04-18 17:29:34 --> Language Class Initialized
DEBUG - 2020-04-18 17:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:29:34 --> Input Class Initialized
INFO - 2020-04-18 17:29:34 --> Loader Class Initialized
INFO - 2020-04-18 17:29:34 --> Helper loaded: url_helper
INFO - 2020-04-18 17:29:34 --> Language Class Initialized
INFO - 2020-04-18 17:29:34 --> Helper loaded: file_helper
INFO - 2020-04-18 17:29:34 --> Loader Class Initialized
INFO - 2020-04-18 17:29:34 --> Helper loaded: form_helper
INFO - 2020-04-18 17:29:34 --> Helper loaded: url_helper
INFO - 2020-04-18 17:29:34 --> Helper loaded: file_helper
INFO - 2020-04-18 17:29:34 --> Database Driver Class Initialized
INFO - 2020-04-18 17:29:34 --> Helper loaded: form_helper
INFO - 2020-04-18 17:29:34 --> Email Class Initialized
DEBUG - 2020-04-18 17:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:29:34 --> Database Driver Class Initialized
INFO - 2020-04-18 17:29:34 --> Email Class Initialized
DEBUG - 2020-04-18 17:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:29:34 --> Config Class Initialized
INFO - 2020-04-18 17:29:34 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:29:35 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:29:35 --> Utf8 Class Initialized
INFO - 2020-04-18 17:29:35 --> URI Class Initialized
INFO - 2020-04-18 17:29:35 --> Router Class Initialized
INFO - 2020-04-18 17:29:35 --> Output Class Initialized
INFO - 2020-04-18 17:29:35 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:35 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:35 --> Security Class Initialized
INFO - 2020-04-18 17:29:35 --> Form Validation Class Initialized
DEBUG - 2020-04-18 17:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:29:35 --> Input Class Initialized
INFO - 2020-04-18 17:29:35 --> Upload Class Initialized
INFO - 2020-04-18 17:29:35 --> Language Class Initialized
INFO - 2020-04-18 17:29:35 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:35 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:35 --> Loader Class Initialized
INFO - 2020-04-18 17:29:35 --> Helper loaded: url_helper
INFO - 2020-04-18 17:29:35 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:35 --> Final output sent to browser
INFO - 2020-04-18 17:29:35 --> Helper loaded: file_helper
DEBUG - 2020-04-18 17:29:35 --> Total execution time: 23.7001
INFO - 2020-04-18 17:29:35 --> Helper loaded: form_helper
INFO - 2020-04-18 17:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:35 --> Database Driver Class Initialized
INFO - 2020-04-18 17:29:35 --> Controller Class Initialized
INFO - 2020-04-18 17:29:35 --> Email Class Initialized
INFO - 2020-04-18 17:29:35 --> Model "ci_ext_model" initialized
DEBUG - 2020-04-18 17:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:29:35 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:35 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:35 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:35 --> Upload Class Initialized
INFO - 2020-04-18 17:29:35 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:36 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:36 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:36 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:36 --> Total execution time: 23.0494
INFO - 2020-04-18 17:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:36 --> Controller Class Initialized
INFO - 2020-04-18 17:29:36 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:36 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:36 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:36 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:36 --> Upload Class Initialized
INFO - 2020-04-18 17:29:36 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:36 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:36 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:37 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:37 --> Total execution time: 23.7948
INFO - 2020-04-18 17:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:37 --> Controller Class Initialized
INFO - 2020-04-18 17:29:37 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:38 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:38 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:38 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:38 --> Upload Class Initialized
INFO - 2020-04-18 17:29:38 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:38 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:38 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:38 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:38 --> Total execution time: 23.6867
INFO - 2020-04-18 17:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:38 --> Controller Class Initialized
INFO - 2020-04-18 17:29:38 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:38 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:38 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:38 --> Config Class Initialized
INFO - 2020-04-18 17:29:38 --> Hooks Class Initialized
INFO - 2020-04-18 17:29:38 --> Form Validation Class Initialized
DEBUG - 2020-04-18 17:29:38 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:29:39 --> Utf8 Class Initialized
INFO - 2020-04-18 17:29:39 --> URI Class Initialized
INFO - 2020-04-18 17:29:39 --> Upload Class Initialized
INFO - 2020-04-18 17:29:39 --> Router Class Initialized
INFO - 2020-04-18 17:29:39 --> Output Class Initialized
INFO - 2020-04-18 17:29:39 --> Security Class Initialized
INFO - 2020-04-18 17:29:39 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:39 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
DEBUG - 2020-04-18 17:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:29:39 --> Input Class Initialized
INFO - 2020-04-18 17:29:39 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:39 --> Final output sent to browser
INFO - 2020-04-18 17:29:39 --> Language Class Initialized
DEBUG - 2020-04-18 17:29:39 --> Total execution time: 24.3766
INFO - 2020-04-18 17:29:39 --> Loader Class Initialized
INFO - 2020-04-18 17:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:39 --> Helper loaded: url_helper
INFO - 2020-04-18 17:29:39 --> Controller Class Initialized
INFO - 2020-04-18 17:29:39 --> Helper loaded: file_helper
INFO - 2020-04-18 17:29:39 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:39 --> Helper loaded: form_helper
INFO - 2020-04-18 17:29:39 --> Database Driver Class Initialized
INFO - 2020-04-18 17:29:39 --> Email Class Initialized
DEBUG - 2020-04-18 17:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:29:40 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:40 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:40 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:40 --> Upload Class Initialized
INFO - 2020-04-18 17:29:40 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:40 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:40 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:40 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:40 --> Total execution time: 23.4011
INFO - 2020-04-18 17:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:40 --> Controller Class Initialized
INFO - 2020-04-18 17:29:40 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:40 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:40 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:40 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:40 --> Upload Class Initialized
INFO - 2020-04-18 17:29:40 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:40 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:41 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:41 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:41 --> Total execution time: 20.5530
INFO - 2020-04-18 17:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:41 --> Controller Class Initialized
INFO - 2020-04-18 17:29:41 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:41 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:41 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:41 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:41 --> Upload Class Initialized
INFO - 2020-04-18 17:29:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-04-18 17:29:41 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:41 --> Total execution time: 18.2118
INFO - 2020-04-18 17:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:41 --> Controller Class Initialized
INFO - 2020-04-18 17:29:41 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:42 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:42 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:42 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:42 --> Upload Class Initialized
INFO - 2020-04-18 17:29:42 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:42 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:42 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:42 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:42 --> Total execution time: 19.1927
INFO - 2020-04-18 17:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:42 --> Config Class Initialized
INFO - 2020-04-18 17:29:42 --> Controller Class Initialized
INFO - 2020-04-18 17:29:42 --> Hooks Class Initialized
INFO - 2020-04-18 17:29:42 --> Model "ci_ext_model" initialized
DEBUG - 2020-04-18 17:29:42 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:29:42 --> Utf8 Class Initialized
INFO - 2020-04-18 17:29:42 --> URI Class Initialized
INFO - 2020-04-18 17:29:42 --> Router Class Initialized
INFO - 2020-04-18 17:29:42 --> Output Class Initialized
INFO - 2020-04-18 17:29:42 --> Security Class Initialized
DEBUG - 2020-04-18 17:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:29:42 --> Input Class Initialized
INFO - 2020-04-18 17:29:42 --> Language Class Initialized
INFO - 2020-04-18 17:29:42 --> Loader Class Initialized
INFO - 2020-04-18 17:29:42 --> Helper loaded: url_helper
INFO - 2020-04-18 17:29:42 --> Helper loaded: file_helper
INFO - 2020-04-18 17:29:42 --> Helper loaded: form_helper
INFO - 2020-04-18 17:29:42 --> Database Driver Class Initialized
INFO - 2020-04-18 17:29:42 --> Email Class Initialized
DEBUG - 2020-04-18 17:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:29:42 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:43 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:43 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:43 --> Upload Class Initialized
INFO - 2020-04-18 17:29:43 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:43 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:43 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:43 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:43 --> Total execution time: 16.0791
INFO - 2020-04-18 17:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:43 --> Controller Class Initialized
INFO - 2020-04-18 17:29:43 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:43 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:43 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:43 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:43 --> Upload Class Initialized
INFO - 2020-04-18 17:29:43 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:43 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:43 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:43 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:43 --> Total execution time: 14.2863
INFO - 2020-04-18 17:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:43 --> Controller Class Initialized
INFO - 2020-04-18 17:29:44 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:44 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:44 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:44 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:44 --> Upload Class Initialized
INFO - 2020-04-18 17:29:44 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:44 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:44 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:44 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:44 --> Total execution time: 10.8192
INFO - 2020-04-18 17:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:44 --> Controller Class Initialized
INFO - 2020-04-18 17:29:44 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:45 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:45 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:45 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:45 --> Upload Class Initialized
INFO - 2020-04-18 17:29:45 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:45 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:45 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:45 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:45 --> Total execution time: 11.5218
INFO - 2020-04-18 17:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:45 --> Controller Class Initialized
INFO - 2020-04-18 17:29:45 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:46 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:46 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:46 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:46 --> Upload Class Initialized
INFO - 2020-04-18 17:29:46 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:46 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:46 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:46 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:46 --> Total execution time: 11.3686
INFO - 2020-04-18 17:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:46 --> Controller Class Initialized
INFO - 2020-04-18 17:29:46 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:46 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:46 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:46 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:46 --> Upload Class Initialized
INFO - 2020-04-18 17:29:46 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:46 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:46 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:47 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:47 --> Total execution time: 8.0525
INFO - 2020-04-18 17:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:47 --> Controller Class Initialized
INFO - 2020-04-18 17:29:47 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:47 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:47 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:47 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:47 --> Upload Class Initialized
INFO - 2020-04-18 17:29:47 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:47 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:47 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:47 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:47 --> Total execution time: 5.2717
INFO - 2020-04-18 17:29:48 --> Config Class Initialized
INFO - 2020-04-18 17:29:48 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:29:48 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:29:48 --> Utf8 Class Initialized
INFO - 2020-04-18 17:29:48 --> URI Class Initialized
INFO - 2020-04-18 17:29:48 --> Router Class Initialized
INFO - 2020-04-18 17:29:48 --> Output Class Initialized
INFO - 2020-04-18 17:29:48 --> Security Class Initialized
DEBUG - 2020-04-18 17:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:29:48 --> Input Class Initialized
INFO - 2020-04-18 17:29:48 --> Language Class Initialized
INFO - 2020-04-18 17:29:48 --> Config Class Initialized
INFO - 2020-04-18 17:29:48 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:29:48 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:29:48 --> Utf8 Class Initialized
INFO - 2020-04-18 17:29:48 --> URI Class Initialized
INFO - 2020-04-18 17:29:48 --> Router Class Initialized
INFO - 2020-04-18 17:29:49 --> Output Class Initialized
INFO - 2020-04-18 17:29:49 --> Security Class Initialized
DEBUG - 2020-04-18 17:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:29:49 --> Input Class Initialized
INFO - 2020-04-18 17:29:49 --> Language Class Initialized
INFO - 2020-04-18 17:29:49 --> Loader Class Initialized
INFO - 2020-04-18 17:29:49 --> Helper loaded: url_helper
INFO - 2020-04-18 17:29:49 --> Helper loaded: file_helper
INFO - 2020-04-18 17:29:49 --> Helper loaded: form_helper
INFO - 2020-04-18 17:29:49 --> Database Driver Class Initialized
INFO - 2020-04-18 17:29:49 --> Email Class Initialized
DEBUG - 2020-04-18 17:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:49 --> Controller Class Initialized
INFO - 2020-04-18 17:29:49 --> File loaded: E:\xampp\htdocs\ouride\application\views\nodata.php
INFO - 2020-04-18 17:29:49 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:49 --> Total execution time: 0.5821
INFO - 2020-04-18 17:29:54 --> Config Class Initialized
INFO - 2020-04-18 17:29:54 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:29:54 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:29:54 --> Utf8 Class Initialized
INFO - 2020-04-18 17:29:54 --> URI Class Initialized
INFO - 2020-04-18 17:29:54 --> Router Class Initialized
INFO - 2020-04-18 17:29:54 --> Output Class Initialized
INFO - 2020-04-18 17:29:54 --> Security Class Initialized
DEBUG - 2020-04-18 17:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:29:54 --> Input Class Initialized
INFO - 2020-04-18 17:29:54 --> Language Class Initialized
INFO - 2020-04-18 17:29:54 --> Loader Class Initialized
INFO - 2020-04-18 17:29:54 --> Helper loaded: url_helper
INFO - 2020-04-18 17:29:54 --> Helper loaded: file_helper
INFO - 2020-04-18 17:29:54 --> Helper loaded: form_helper
INFO - 2020-04-18 17:29:54 --> Database Driver Class Initialized
INFO - 2020-04-18 17:29:54 --> Email Class Initialized
DEBUG - 2020-04-18 17:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:54 --> Controller Class Initialized
INFO - 2020-04-18 17:29:54 --> Model "ci_ext_model" initialized
INFO - 2020-04-18 17:29:55 --> Model "Mitra_model" initialized
INFO - 2020-04-18 17:29:55 --> Model "Appsettings_model" initialized
INFO - 2020-04-18 17:29:55 --> Form Validation Class Initialized
INFO - 2020-04-18 17:29:55 --> Upload Class Initialized
INFO - 2020-04-18 17:29:55 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/header.php
INFO - 2020-04-18 17:29:55 --> File loaded: E:\xampp\htdocs\ouride\application\views\mitra/detail.php
INFO - 2020-04-18 17:29:56 --> File loaded: E:\xampp\htdocs\ouride\application\views\includes/footer.php
INFO - 2020-04-18 17:29:56 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:56 --> Total execution time: 2.0688
INFO - 2020-04-18 17:29:56 --> Config Class Initialized
INFO - 2020-04-18 17:29:56 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:29:56 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:29:56 --> Utf8 Class Initialized
INFO - 2020-04-18 17:29:56 --> URI Class Initialized
INFO - 2020-04-18 17:29:56 --> Router Class Initialized
INFO - 2020-04-18 17:29:56 --> Output Class Initialized
INFO - 2020-04-18 17:29:56 --> Security Class Initialized
DEBUG - 2020-04-18 17:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:29:56 --> Input Class Initialized
INFO - 2020-04-18 17:29:56 --> Language Class Initialized
INFO - 2020-04-18 17:29:56 --> Config Class Initialized
INFO - 2020-04-18 17:29:56 --> Hooks Class Initialized
DEBUG - 2020-04-18 17:29:56 --> UTF-8 Support Enabled
INFO - 2020-04-18 17:29:56 --> Utf8 Class Initialized
INFO - 2020-04-18 17:29:56 --> URI Class Initialized
INFO - 2020-04-18 17:29:56 --> Router Class Initialized
INFO - 2020-04-18 17:29:56 --> Output Class Initialized
INFO - 2020-04-18 17:29:56 --> Security Class Initialized
DEBUG - 2020-04-18 17:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-18 17:29:57 --> Input Class Initialized
INFO - 2020-04-18 17:29:57 --> Language Class Initialized
INFO - 2020-04-18 17:29:57 --> Loader Class Initialized
INFO - 2020-04-18 17:29:57 --> Helper loaded: url_helper
INFO - 2020-04-18 17:29:57 --> Helper loaded: file_helper
INFO - 2020-04-18 17:29:57 --> Helper loaded: form_helper
INFO - 2020-04-18 17:29:57 --> Database Driver Class Initialized
INFO - 2020-04-18 17:29:57 --> Email Class Initialized
DEBUG - 2020-04-18 17:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-18 17:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-18 17:29:57 --> Controller Class Initialized
INFO - 2020-04-18 17:29:57 --> File loaded: E:\xampp\htdocs\ouride\application\views\nodata.php
INFO - 2020-04-18 17:29:57 --> Final output sent to browser
DEBUG - 2020-04-18 17:29:57 --> Total execution time: 0.4464
